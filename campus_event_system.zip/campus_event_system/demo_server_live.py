#!/usr/bin/env python3
"""
Live demo server with SQLite database for Campus Event System
This creates a working FastAPI server with real database operations
"""

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from sqlalchemy import create_engine, Column, String, Text, Integer, Boolean, DateTime, Enum, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session, relationship
from sqlalchemy.sql import func
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime
import uuid
import enum
import json

# Database setup
DATABASE_URL = "sqlite:///./campus_events_demo.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Enums
class EventType(str, enum.Enum):
    workshop = "workshop"
    seminar = "seminar"
    hackathon = "hackathon"
    fest = "fest"
    other = "other"

class RegistrationStatus(str, enum.Enum):
    registered = "registered"
    cancelled = "cancelled"
    waitlisted = "waitlisted"

# Models
class College(Base):
    __tablename__ = "colleges"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False)
    code = Column(String(10), unique=True, nullable=False)
    address = Column(Text)
    contact_email = Column(String(255))
    created_at = Column(DateTime, server_default=func.now())
    
    events = relationship("Event", back_populates="college")
    students = relationship("Student", back_populates="college")

class Event(Base):
    __tablename__ = "events"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    college_id = Column(String, ForeignKey("colleges.id"), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    event_type = Column(Enum(EventType), nullable=False)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    venue = Column(String(255))
    max_capacity = Column(Integer)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())
    
    college = relationship("College", back_populates="events")
    registrations = relationship("Registration", back_populates="event")

class Student(Base):
    __tablename__ = "students"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    college_id = Column(String, ForeignKey("colleges.id"), nullable=False)
    student_id = Column(String(50), nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    phone = Column(String(20))
    department = Column(String(100))
    year = Column(Integer)
    created_at = Column(DateTime, server_default=func.now())
    
    college = relationship("College", back_populates="students")
    registrations = relationship("Registration", back_populates="student")

class Registration(Base):
    __tablename__ = "registrations"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    event_id = Column(String, ForeignKey("events.id"), nullable=False)
    student_id = Column(String, ForeignKey("students.id"), nullable=False)
    registration_time = Column(DateTime, server_default=func.now())
    status = Column(Enum(RegistrationStatus), default=RegistrationStatus.registered)
    created_at = Column(DateTime, server_default=func.now())
    
    event = relationship("Event", back_populates="registrations")
    student = relationship("Student", back_populates="registrations")

# Pydantic schemas
class CollegeCreate(BaseModel):
    name: str
    code: str
    address: Optional[str] = None
    contact_email: Optional[str] = None

class StudentCreate(BaseModel):
    college_id: str
    student_id: str
    first_name: str
    last_name: str
    email: str
    phone: Optional[str] = None
    department: Optional[str] = None
    year: Optional[int] = None

class EventCreate(BaseModel):
    title: str
    description: Optional[str] = None
    event_type: EventType
    start_time: datetime
    end_time: datetime
    venue: Optional[str] = None
    max_capacity: Optional[int] = None

class RegistrationCreate(BaseModel):
    event_id: str
    student_id: str

# Database dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Create FastAPI app
app = FastAPI(title="Campus Event System - Live Demo", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create tables
Base.metadata.create_all(bind=engine)

# Initialize sample data
def init_sample_data():
    db = SessionLocal()
    try:
        # Check if data already exists
        if db.query(College).count() > 0:
            return
        
        # Create colleges
        colleges_data = [
            {"name": "Tech University", "code": "TU", "address": "123 Tech Street", "contact_email": "admin@techuni.edu"},
            {"name": "Engineering College", "code": "EC", "address": "456 Engineering Ave", "contact_email": "info@engcollege.edu"},
            {"name": "Science Institute", "code": "SI", "address": "789 Science Blvd", "contact_email": "contact@sciinst.edu"}
        ]
        
        colleges = []
        for college_data in colleges_data:
            college = College(**college_data)
            db.add(college)
            colleges.append(college)
        db.commit()
        
        # Create sample students
        students_data = [
            {"college_id": colleges[0].id, "student_id": "TU2024001", "first_name": "John", "last_name": "Doe", 
             "email": "john.doe@techuni.edu", "department": "Computer Science", "year": 3},
            {"college_id": colleges[0].id, "student_id": "TU2024002", "first_name": "Jane", "last_name": "Smith", 
             "email": "jane.smith@techuni.edu", "department": "Data Science", "year": 2},
            {"college_id": colleges[1].id, "student_id": "EC2024001", "first_name": "Mike", "last_name": "Johnson", 
             "email": "mike.johnson@engcollege.edu", "department": "Mechanical Engineering", "year": 4},
        ]
        
        students = []
        for student_data in students_data:
            student = Student(**student_data)
            db.add(student)
            students.append(student)
        db.commit()
        
        # Create sample events
        events_data = [
            {"college_id": colleges[0].id, "title": "AI/ML Workshop", "description": "Hands-on machine learning workshop",
             "event_type": EventType.workshop, "start_time": datetime(2024, 4, 15, 10, 0), 
             "end_time": datetime(2024, 4, 15, 16, 0), "venue": "Computer Lab 1", "max_capacity": 50},
            {"college_id": colleges[0].id, "title": "Tech Fest 2024", "description": "Annual technology festival",
             "event_type": EventType.fest, "start_time": datetime(2024, 4, 20, 9, 0), 
             "end_time": datetime(2024, 4, 22, 18, 0), "venue": "Main Auditorium", "max_capacity": 500},
            {"college_id": colleges[1].id, "title": "Robotics Seminar", "description": "Latest trends in robotics",
             "event_type": EventType.seminar, "start_time": datetime(2024, 4, 18, 14, 0), 
             "end_time": datetime(2024, 4, 18, 17, 0), "venue": "Seminar Hall A", "max_capacity": 100},
        ]
        
        events = []
        for event_data in events_data:
            event = Event(**event_data)
            db.add(event)
            events.append(event)
        db.commit()
        
        # Create sample registrations
        registrations_data = [
            {"event_id": events[0].id, "student_id": students[0].id},
            {"event_id": events[0].id, "student_id": students[1].id},
            {"event_id": events[1].id, "student_id": students[0].id},
            {"event_id": events[2].id, "student_id": students[2].id},
        ]
        
        for reg_data in registrations_data:
            registration = Registration(**reg_data)
            db.add(registration)
        db.commit()
        
        print("✅ Sample data initialized successfully!")
        
    except Exception as e:
        print(f"Error initializing sample data: {e}")
        db.rollback()
    finally:
        db.close()

# Initialize data on startup
init_sample_data()

# API Routes
@app.get("/")
async def root():
    return {
        "message": "Campus Event System - Live Demo with Database",
        "version": "1.0.0",
        "database": "SQLite",
        "endpoints": {
            "colleges": "/api/v1/colleges/",
            "students": "/api/v1/students/",
            "events": "/api/v1/events/",
            "registrations": "/api/v1/registrations/",
            "dashboard": "/dashboard"
        }
    }

@app.get("/api/v1/colleges/")
async def get_colleges(db: Session = Depends(get_db)):
    colleges = db.query(College).all()
    return [{"id": c.id, "name": c.name, "code": c.code, "address": c.address, "contact_email": c.contact_email} for c in colleges]

@app.post("/api/v1/colleges/")
async def create_college(college: CollegeCreate, db: Session = Depends(get_db)):
    db_college = College(**college.dict())
    db.add(db_college)
    db.commit()
    db.refresh(db_college)
    return {"id": db_college.id, "name": db_college.name, "code": db_college.code}

@app.get("/api/v1/students/")
async def get_students(db: Session = Depends(get_db)):
    students = db.query(Student).join(College).all()
    return [{
        "id": s.id, "student_id": s.student_id, "first_name": s.first_name, 
        "last_name": s.last_name, "email": s.email, "department": s.department, 
        "year": s.year, "college_name": s.college.name
    } for s in students]

@app.post("/api/v1/students/")
async def create_student(student: StudentCreate, db: Session = Depends(get_db)):
    # Check if email exists
    existing = db.query(Student).filter(Student.email == student.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    db_student = Student(**student.dict())
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return {"id": db_student.id, "message": "Student registered successfully", "student_id": db_student.student_id}

@app.get("/api/v1/events/")
async def get_events(db: Session = Depends(get_db)):
    events = db.query(Event).join(College).all()
    result = []
    for e in events:
        reg_count = db.query(Registration).filter(Registration.event_id == e.id).count()
        result.append({
            "id": e.id, "title": e.title, "description": e.description,
            "event_type": e.event_type, "start_time": e.start_time.isoformat(),
            "end_time": e.end_time.isoformat(), "venue": e.venue,
            "max_capacity": e.max_capacity, "college_name": e.college.name,
            "registrations_count": reg_count
        })
    return result

@app.post("/api/v1/events/")
async def create_event(event: EventCreate, db: Session = Depends(get_db)):
    # Use first college for demo
    college = db.query(College).first()
    event_dict = event.dict()
    event_dict["college_id"] = college.id
    
    db_event = Event(**event_dict)
    db.add(db_event)
    db.commit()
    db.refresh(db_event)
    return {"id": db_event.id, "message": "Event created successfully", "title": db_event.title}

@app.get("/api/v1/registrations/")
async def get_registrations(db: Session = Depends(get_db)):
    registrations = db.query(Registration).join(Event).join(Student).all()
    return [{
        "id": r.id, "event_title": r.event.title, "student_name": f"{r.student.first_name} {r.student.last_name}",
        "student_email": r.student.email, "registration_time": r.registration_time.isoformat(),
        "status": r.status
    } for r in registrations]

@app.post("/api/v1/registrations/")
async def create_registration(registration: RegistrationCreate, db: Session = Depends(get_db)):
    # Check if already registered
    existing = db.query(Registration).filter(
        Registration.event_id == registration.event_id,
        Registration.student_id == registration.student_id
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="Already registered for this event")
    
    db_registration = Registration(**registration.dict())
    db.add(db_registration)
    db.commit()
    db.refresh(db_registration)
    return {"id": db_registration.id, "message": "Registration successful"}

@app.get("/api/v1/reports/dashboard")
async def get_dashboard_stats(db: Session = Depends(get_db)):
    total_colleges = db.query(College).count()
    total_students = db.query(Student).count()
    total_events = db.query(Event).count()
    total_registrations = db.query(Registration).count()
    
    return {
        "total_colleges": total_colleges,
        "total_students": total_students,
        "total_events": total_events,
        "total_registrations": total_registrations,
        "timestamp": datetime.now().isoformat()
    }

# Serve the dashboard HTML
@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Campus Event System - Live Dashboard</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header { text-align: center; margin-bottom: 30px; }
            .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
            .stat-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }
            .stat-number { font-size: 2em; font-weight: bold; }
            .stat-label { margin-top: 10px; opacity: 0.9; }
            .section { margin-bottom: 30px; }
            .section h3 { color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
            .api-test { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 10px 0; }
            .api-test button { background: #667eea; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin-right: 10px; }
            .api-test button:hover { background: #5a67d8; }
            .result { background: #e8f5e8; border: 1px solid #4caf50; padding: 15px; border-radius: 5px; margin-top: 10px; font-family: monospace; white-space: pre-wrap; }
            .form-group { margin-bottom: 15px; }
            .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
            .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🎓 Campus Event System - Live Dashboard</h1>
                <p>Real-time database operations with SQLite</p>
            </div>
            
            <div class="stats" id="stats">
                <div class="stat-card">
                    <div class="stat-number" id="colleges">-</div>
                    <div class="stat-label">Colleges</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" id="students">-</div>
                    <div class="stat-label">Students</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" id="events">-</div>
                    <div class="stat-label">Events</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" id="registrations">-</div>
                    <div class="stat-label">Registrations</div>
                </div>
            </div>
            
            <div class="section">
                <h3>📊 Live API Testing</h3>
                
                <div class="api-test">
                    <h4>Get All Data</h4>
                    <button onclick="fetchData('/api/v1/colleges/', 'colleges-result')">Get Colleges</button>
                    <button onclick="fetchData('/api/v1/students/', 'students-result')">Get Students</button>
                    <button onclick="fetchData('/api/v1/events/', 'events-result')">Get Events</button>
                    <button onclick="fetchData('/api/v1/registrations/', 'registrations-result')">Get Registrations</button>
                    <div id="colleges-result" class="result" style="display:none;"></div>
                    <div id="students-result" class="result" style="display:none;"></div>
                    <div id="events-result" class="result" style="display:none;"></div>
                    <div id="registrations-result" class="result" style="display:none;"></div>
                </div>
                
                <div class="api-test">
                    <h4>Add New Student</h4>
                    <div class="form-group">
                        <label>First Name:</label>
                        <input type="text" id="firstName" placeholder="Enter first name">
                    </div>
                    <div class="form-group">
                        <label>Last Name:</label>
                        <input type="text" id="lastName" placeholder="Enter last name">
                    </div>
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" id="email" placeholder="Enter email">
                    </div>
                    <div class="form-group">
                        <label>Student ID:</label>
                        <input type="text" id="studentId" placeholder="e.g., TU2024999">
                    </div>
                    <div class="form-group">
                        <label>Department:</label>
                        <input type="text" id="department" placeholder="e.g., Computer Science">
                    </div>
                    <button onclick="addStudent()">Add Student</button>
                    <div id="add-student-result" class="result" style="display:none;"></div>
                </div>
                
                <div class="api-test">
                    <h4>Add New Event</h4>
                    <div class="form-group">
                        <label>Event Title:</label>
                        <input type="text" id="eventTitle" placeholder="Enter event title">
                    </div>
                    <div class="form-group">
                        <label>Description:</label>
                        <textarea id="eventDescription" placeholder="Enter event description"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Event Type:</label>
                        <select id="eventType">
                            <option value="workshop">Workshop</option>
                            <option value="seminar">Seminar</option>
                            <option value="hackathon">Hackathon</option>
                            <option value="fest">Fest</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Venue:</label>
                        <input type="text" id="eventVenue" placeholder="Enter venue">
                    </div>
                    <div class="form-group">
                        <label>Max Capacity:</label>
                        <input type="number" id="eventCapacity" placeholder="Enter max capacity">
                    </div>
                    <button onclick="addEvent()">Add Event</button>
                    <div id="add-event-result" class="result" style="display:none;"></div>
                </div>
            </div>
        </div>
        
        <script>
            // Load dashboard stats
            async function loadStats() {
                try {
                    const response = await fetch('/api/v1/reports/dashboard');
                    const data = await response.json();
                    document.getElementById('colleges').textContent = data.total_colleges;
                    document.getElementById('students').textContent = data.total_students;
                    document.getElementById('events').textContent = data.total_events;
                    document.getElementById('registrations').textContent = data.total_registrations;
                } catch (error) {
                    console.error('Error loading stats:', error);
                }
            }
            
            // Fetch data from API
            async function fetchData(endpoint, resultId) {
                try {
                    const response = await fetch(endpoint);
                    const data = await response.json();
                    const resultDiv = document.getElementById(resultId);
                    resultDiv.textContent = JSON.stringify(data, null, 2);
                    resultDiv.style.display = 'block';
                } catch (error) {
                    console.error('Error fetching data:', error);
                }
            }
            
            // Add new student
            async function addStudent() {
                const studentData = {
                    college_id: "1", // Use first college
                    student_id: document.getElementById('studentId').value,
                    first_name: document.getElementById('firstName').value,
                    last_name: document.getElementById('lastName').value,
                    email: document.getElementById('email').value,
                    department: document.getElementById('department').value,
                    year: 2
                };
                
                try {
                    const response = await fetch('/api/v1/students/', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify(studentData)
                    });
                    const result = await response.json();
                    const resultDiv = document.getElementById('add-student-result');
                    resultDiv.textContent = JSON.stringify(result, null, 2);
                    resultDiv.style.display = 'block';
                    loadStats(); // Refresh stats
                } catch (error) {
                    console.error('Error adding student:', error);
                }
            }
            
            // Add new event
            async function addEvent() {
                const eventData = {
                    title: document.getElementById('eventTitle').value,
                    description: document.getElementById('eventDescription').value,
                    event_type: document.getElementById('eventType').value,
                    start_time: new Date(Date.now() + 7*24*60*60*1000).toISOString(), // Next week
                    end_time: new Date(Date.now() + 7*24*60*60*1000 + 6*60*60*1000).toISOString(), // +6 hours
                    venue: document.getElementById('eventVenue').value,
                    max_capacity: parseInt(document.getElementById('eventCapacity').value)
                };
                
                try {
                    const response = await fetch('/api/v1/events/', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify(eventData)
                    });
                    const result = await response.json();
                    const resultDiv = document.getElementById('add-event-result');
                    resultDiv.textContent = JSON.stringify(result, null, 2);
                    resultDiv.style.display = 'block';
                    loadStats(); // Refresh stats
                } catch (error) {
                    console.error('Error adding event:', error);
                }
            }
            
            // Load stats on page load
            loadStats();
            
            // Auto-refresh stats every 10 seconds
            setInterval(loadStats, 10000);
        </script>
    </body>
    </html>
    """

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Campus Event System Live Demo")
    print("📊 Dashboard: http://localhost:8000/dashboard")
    print("🔌 API Docs: http://localhost:8000/docs")
    print("💾 Database: SQLite (campus_events_demo.db)")
    uvicorn.run(app, host="0.0.0.0", port=8000)
