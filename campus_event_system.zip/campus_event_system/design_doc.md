# Campus Event System - Design Document

## 1. System Overview

The Campus Event System is designed to manage college events and provide comprehensive reporting capabilities. The system consists of an Admin Portal for event management and a Student App for event participation, with a focus on robust reporting functionality.

### 1.1 Assumptions & Decisions

**Scale Assumptions:**
- ~50 colleges in the system
- ~500 students per college (25,000 total students)
- ~20 events per semester per college
- Event IDs are globally unique across all colleges
- Single shared database with college_id partitioning

**Technical Decisions:**
- **Backend**: FastAPI with SQLAlchemy ORM for high performance and automatic API documentation
- **Database**: PostgreSQL for ACID compliance and complex query support
- **Authentication**: JWT-based with simplified implementation for prototype
- **API Design**: RESTful with clear resource-based endpoints
- **Data Storage**: Normalized database design with proper foreign key relationships

**Business Logic Decisions:**
- Students can register for multiple events
- Attendance can only be marked for registered students
- Feedback is optional but encouraged
- Events can be cancelled (soft delete approach)
- Duplicate registrations are prevented at database level

## 2. Data Model

### 2.1 Entities to Track

1. **Colleges**: Institution information
2. **Events**: Hackathons, workshops, seminars, fests
3. **Students**: Student profiles and college affiliation
4. **Registrations**: Student event registrations
5. **Attendance**: Attendance records for registered students
6. **Feedback**: Student feedback and ratings for attended events
7. **Users**: Admin users for event management

### 2.2 Database Schema

#### ER Diagram (Mermaid)

```mermaid
erDiagram
    COLLEGES ||--o{ EVENTS : hosts
    COLLEGES ||--o{ STUDENTS : enrolls
    COLLEGES ||--o{ USERS : employs
    EVENTS ||--o{ REGISTRATIONS : receives
    EVENTS ||--o{ ATTENDANCE : tracks
    EVENTS ||--o{ FEEDBACK : collects
    STUDENTS ||--o{ REGISTRATIONS : makes
    STUDENTS ||--o{ ATTENDANCE : records
    STUDENTS ||--o{ FEEDBACK : provides
    REGISTRATIONS ||--|| ATTENDANCE : enables
    ATTENDANCE ||--|| FEEDBACK : allows

    COLLEGES {
        uuid id PK
        string name
        string code
        string address
        string contact_email
        string contact_phone
        timestamp created_at
        timestamp updated_at
    }

    EVENTS {
        uuid id PK
        uuid college_id FK
        string title
        text description
        enum event_type
        datetime start_time
        datetime end_time
        string venue
        integer max_capacity
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    STUDENTS {
        uuid id PK
        uuid college_id FK
        string student_id
        string first_name
        string last_name
        string email
        string phone
        string department
        integer year
        timestamp created_at
        timestamp updated_at
    }

    USERS {
        uuid id PK
        uuid college_id FK
        string username
        string email
        string password_hash
        enum role
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    REGISTRATIONS {
        uuid id PK
        uuid event_id FK
        uuid student_id FK
        timestamp registration_time
        enum status
        timestamp created_at
    }

    ATTENDANCE {
        uuid id PK
        uuid registration_id FK
        timestamp check_in_time
        timestamp check_out_time
        text notes
        timestamp created_at
    }

    FEEDBACK {
        uuid id PK
        uuid attendance_id FK
        integer rating
        text comments
        json feedback_data
        timestamp created_at
    }
```

#### Table Definitions

**colleges**
- `id` (UUID, Primary Key)
- `name` (VARCHAR(255), NOT NULL)
- `code` (VARCHAR(10), UNIQUE, NOT NULL)
- `address` (TEXT)
- `contact_email` (VARCHAR(255))
- `contact_phone` (VARCHAR(20))
- `created_at` (TIMESTAMP, DEFAULT NOW())
- `updated_at` (TIMESTAMP, DEFAULT NOW())

**events**
- `id` (UUID, Primary Key)
- `college_id` (UUID, Foreign Key → colleges.id)
- `title` (VARCHAR(255), NOT NULL)
- `description` (TEXT)
- `event_type` (ENUM: 'workshop', 'seminar', 'hackathon', 'fest', 'other')
- `start_time` (TIMESTAMP, NOT NULL)
- `end_time` (TIMESTAMP, NOT NULL)
- `venue` (VARCHAR(255))
- `max_capacity` (INTEGER)
- `is_active` (BOOLEAN, DEFAULT TRUE)
- `created_at` (TIMESTAMP, DEFAULT NOW())
- `updated_at` (TIMESTAMP, DEFAULT NOW())

**students**
- `id` (UUID, Primary Key)
- `college_id` (UUID, Foreign Key → colleges.id)
- `student_id` (VARCHAR(50), NOT NULL)
- `first_name` (VARCHAR(100), NOT NULL)
- `last_name` (VARCHAR(100), NOT NULL)
- `email` (VARCHAR(255), UNIQUE, NOT NULL)
- `phone` (VARCHAR(20))
- `department` (VARCHAR(100))
- `year` (INTEGER)
- `created_at` (TIMESTAMP, DEFAULT NOW())
- `updated_at` (TIMESTAMP, DEFAULT NOW())

**registrations**
- `id` (UUID, Primary Key)
- `event_id` (UUID, Foreign Key → events.id)
- `student_id` (UUID, Foreign Key → students.id)
- `registration_time` (TIMESTAMP, DEFAULT NOW())
- `status` (ENUM: 'registered', 'cancelled', 'waitlisted')
- `created_at` (TIMESTAMP, DEFAULT NOW())
- UNIQUE constraint on (event_id, student_id)

**attendance**
- `id` (UUID, Primary Key)
- `registration_id` (UUID, Foreign Key → registrations.id)
- `check_in_time` (TIMESTAMP, NOT NULL)
- `check_out_time` (TIMESTAMP)
- `notes` (TEXT)
- `created_at` (TIMESTAMP, DEFAULT NOW())

**feedback**
- `id` (UUID, Primary Key)
- `attendance_id` (UUID, Foreign Key → attendance.id)
- `rating` (INTEGER, CHECK rating >= 1 AND rating <= 5)
- `comments` (TEXT)
- `feedback_data` (JSONB) -- For structured feedback forms
- `created_at` (TIMESTAMP, DEFAULT NOW())

## 3. API Design

### 3.1 Base URL Structure
```
https://api.campusevents.com/v1
```

### 3.2 Authentication Endpoints

#### POST /auth/login
**Request:**
```json
{
  "username": "admin@college.edu",
  "password": "password123"
}
```
**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 3600,
  "user": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "username": "admin@college.edu",
    "role": "admin",
    "college_id": "550e8400-e29b-41d4-a716-446655440001"
  }
}
```

### 3.3 Event Management Endpoints

#### POST /events
**Request:**
```json
{
  "title": "AI/ML Workshop",
  "description": "Hands-on workshop on machine learning basics",
  "event_type": "workshop",
  "start_time": "2024-03-15T10:00:00Z",
  "end_time": "2024-03-15T16:00:00Z",
  "venue": "Computer Lab 1",
  "max_capacity": 50
}
```
**Response:**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440002",
  "college_id": "550e8400-e29b-41d4-a716-446655440001",
  "title": "AI/ML Workshop",
  "description": "Hands-on workshop on machine learning basics",
  "event_type": "workshop",
  "start_time": "2024-03-15T10:00:00Z",
  "end_time": "2024-03-15T16:00:00Z",
  "venue": "Computer Lab 1",
  "max_capacity": 50,
  "is_active": true,
  "created_at": "2024-03-01T09:00:00Z"
}
```

#### GET /events
**Query Parameters:**
- `event_type`: Filter by event type
- `college_id`: Filter by college
- `is_active`: Filter active/inactive events
- `limit`: Number of results (default: 50)
- `offset`: Pagination offset

**Response:**
```json
{
  "events": [...],
  "total": 150,
  "limit": 50,
  "offset": 0
}
```

### 3.4 Student Registration Endpoints

#### POST /events/{event_id}/register
**Request:**
```json
{
  "student_id": "550e8400-e29b-41d4-a716-446655440003"
}
```
**Response:**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440004",
  "event_id": "550e8400-e29b-41d4-a716-446655440002",
  "student_id": "550e8400-e29b-41d4-a716-446655440003",
  "registration_time": "2024-03-10T14:30:00Z",
  "status": "registered"
}
```

### 3.5 Attendance Endpoints

#### POST /attendance
**Request:**
```json
{
  "registration_id": "550e8400-e29b-41d4-a716-446655440004",
  "check_in_time": "2024-03-15T10:05:00Z",
  "notes": "Arrived on time"
}
```

#### PUT /attendance/{attendance_id}/checkout
**Request:**
```json
{
  "check_out_time": "2024-03-15T15:45:00Z"
}
```

### 3.6 Feedback Endpoints

#### POST /feedback
**Request:**
```json
{
  "attendance_id": "550e8400-e29b-41d4-a716-446655440005",
  "rating": 4,
  "comments": "Great workshop! Learned a lot about ML algorithms.",
  "feedback_data": {
    "content_quality": 5,
    "instructor_rating": 4,
    "venue_rating": 3,
    "would_recommend": true
  }
}
```

### 3.7 Reporting Endpoints

#### GET /reports/registrations-per-event
**Query Parameters:**
- `college_id`: Filter by college
- `event_type`: Filter by event type
- `start_date`, `end_date`: Date range filter

**Response:**
```json
{
  "report_type": "registrations_per_event",
  "generated_at": "2024-03-20T10:00:00Z",
  "data": [
    {
      "event_id": "550e8400-e29b-41d4-a716-446655440002",
      "event_title": "AI/ML Workshop",
      "event_type": "workshop",
      "college_name": "Tech University",
      "total_registrations": 45,
      "active_registrations": 43,
      "cancelled_registrations": 2,
      "capacity_utilization": 86.0
    }
  ]
}
```

#### GET /reports/attendance-percentage
**Response:**
```json
{
  "report_type": "attendance_percentage",
  "data": [
    {
      "event_id": "550e8400-e29b-41d4-a716-446655440002",
      "event_title": "AI/ML Workshop",
      "total_registrations": 45,
      "total_attendance": 38,
      "attendance_percentage": 84.4
    }
  ]
}
```

#### GET /reports/average-feedback-score
**Response:**
```json
{
  "report_type": "average_feedback_score",
  "data": [
    {
      "event_id": "550e8400-e29b-41d4-a716-446655440002",
      "event_title": "AI/ML Workshop",
      "total_feedback": 35,
      "average_rating": 4.2,
      "rating_distribution": {
        "5": 12,
        "4": 18,
        "3": 4,
        "2": 1,
        "1": 0
      }
    }
  ]
}
```

#### GET /reports/event-popularity
**Response:**
```json
{
  "report_type": "event_popularity",
  "data": [
    {
      "rank": 1,
      "event_id": "550e8400-e29b-41d4-a716-446655440002",
      "event_title": "AI/ML Workshop",
      "event_type": "workshop",
      "total_registrations": 45,
      "attendance_rate": 84.4,
      "average_rating": 4.2
    }
  ]
}
```

#### GET /reports/student-participation
**Response:**
```json
{
  "report_type": "student_participation",
  "data": [
    {
      "student_id": "550e8400-e29b-41d4-a716-446655440003",
      "student_name": "John Doe",
      "college_name": "Tech University",
      "total_registrations": 8,
      "total_attendance": 7,
      "attendance_rate": 87.5,
      "events_attended": [
        {
          "event_title": "AI/ML Workshop",
          "event_type": "workshop",
          "attendance_date": "2024-03-15"
        }
      ]
    }
  ]
}
```

#### GET /reports/top-active-students
**Response:**
```json
{
  "report_type": "top_active_students",
  "data": [
    {
      "rank": 1,
      "student_id": "550e8400-e29b-41d4-a716-446655440003",
      "student_name": "John Doe",
      "college_name": "Tech University",
      "events_attended": 12,
      "average_rating_given": 4.3
    },
    {
      "rank": 2,
      "student_id": "550e8400-e29b-41d4-a716-446655440006",
      "student_name": "Jane Smith",
      "college_name": "Tech University",
      "events_attended": 10,
      "average_rating_given": 4.1
    },
    {
      "rank": 3,
      "student_id": "550e8400-e29b-41d4-a716-446655440007",
      "student_name": "Mike Johnson",
      "college_name": "Engineering College",
      "events_attended": 9,
      "average_rating_given": 4.5
    }
  ]
}
```

## 4. Workflows

### 4.1 Event Registration Workflow

```mermaid
sequenceDiagram
    participant S as Student App
    participant API as FastAPI Backend
    participant DB as PostgreSQL

    S->>API: GET /events (browse available events)
    API->>DB: Query active events
    DB-->>API: Return events list
    API-->>S: Events with availability

    S->>API: POST /events/{id}/register
    API->>DB: Check event capacity & student eligibility
    
    alt Capacity Available
        DB-->>API: Capacity OK
        API->>DB: Insert registration record
        DB-->>API: Registration created
        API-->>S: Registration successful
    else Event Full
        DB-->>API: Capacity exceeded
        API-->>S: Registration failed (waitlist option)
    end
```

### 4.2 Attendance Marking Workflow

```mermaid
sequenceDiagram
    participant A as Admin/QR Scanner
    participant API as FastAPI Backend
    participant DB as PostgreSQL

    A->>API: POST /attendance (check-in)
    API->>DB: Verify registration exists
    
    alt Valid Registration
        DB-->>API: Registration found
        API->>DB: Create attendance record
        DB-->>API: Attendance recorded
        API-->>A: Check-in successful
    else Invalid Registration
        DB-->>API: No registration found
        API-->>A: Check-in failed
    end

    Note over A,DB: Event concludes

    A->>API: PUT /attendance/{id}/checkout
    API->>DB: Update attendance record
    DB-->>API: Check-out recorded
    API-->>A: Check-out successful
```

### 4.3 Feedback Collection Workflow

```mermaid
sequenceDiagram
    participant S as Student App
    participant API as FastAPI Backend
    participant DB as PostgreSQL

    S->>API: GET /events/{id}/feedback-form
    API->>DB: Check attendance record
    
    alt Attended Event
        DB-->>API: Attendance confirmed
        API-->>S: Feedback form
        S->>API: POST /feedback
        API->>DB: Store feedback
        DB-->>API: Feedback saved
        API-->>S: Thank you message
    else Did Not Attend
        DB-->>API: No attendance record
        API-->>S: Feedback not available
    end
```

### 4.4 Report Generation Workflow

```mermaid
sequenceDiagram
    participant A as Admin Portal
    participant API as FastAPI Backend
    participant DB as PostgreSQL
    participant Cache as Redis (Optional)

    A->>API: GET /reports/{report_type}
    API->>Cache: Check cached report
    
    alt Cache Hit
        Cache-->>API: Return cached data
        API-->>A: Report data
    else Cache Miss
        API->>DB: Execute complex query
        DB-->>API: Raw report data
        API->>API: Process & format data
        API->>Cache: Store in cache
        API-->>A: Report data
    end
```

## 5. Edge Cases & Error Handling

### 5.1 Duplicate Registrations
- **Prevention**: Unique constraint on (event_id, student_id)
- **Handling**: Return 409 Conflict with clear error message
- **User Experience**: Show "Already registered" status

### 5.2 Cancelled Events
- **Approach**: Soft delete (is_active = false)
- **Impact**: Existing registrations remain for historical data
- **Notifications**: Send cancellation emails to registered students

### 5.3 Missing Feedback
- **Handling**: Feedback is optional, reports show participation rates
- **Encouragement**: Send reminder notifications post-event
- **Analytics**: Track feedback completion rates

### 5.4 Capacity Management
- **Overflow**: Implement waitlist functionality
- **Real-time Updates**: Use database constraints and transactions
- **Race Conditions**: Handle concurrent registrations with proper locking

### 5.5 Data Integrity
- **Foreign Key Constraints**: Prevent orphaned records
- **Validation**: Comprehensive input validation at API level
- **Audit Trail**: Track all modifications with timestamps

### 5.6 Performance Considerations
- **Database Indexing**: Strategic indexes on frequently queried fields
- **Query Optimization**: Use proper JOINs and avoid N+1 queries
- **Caching**: Cache frequently accessed reports
- **Pagination**: Implement cursor-based pagination for large datasets

## 6. Security Considerations

### 6.1 Authentication & Authorization
- JWT tokens with reasonable expiration times
- Role-based access control (Admin, Student)
- College-level data isolation

### 6.2 Data Protection
- Input sanitization and validation
- SQL injection prevention through ORM
- Rate limiting on API endpoints
- HTTPS enforcement

### 6.3 Privacy
- Student data anonymization in reports
- GDPR compliance considerations
- Audit logging for sensitive operations

## 7. Future Enhancements

### 7.1 Real-time Features
- WebSocket connections for live updates
- Push notifications for event reminders
- Real-time capacity monitoring

### 7.2 Advanced Analytics
- Machine learning for event recommendations
- Predictive analytics for attendance
- Sentiment analysis of feedback

### 7.3 Integration Capabilities
- Calendar system integration
- Email/SMS notification services
- Payment gateway for paid events
- Social media integration for event promotion

This design document provides a comprehensive foundation for implementing the Campus Event System with robust reporting capabilities while maintaining scalability and extensibility for future enhancements.
