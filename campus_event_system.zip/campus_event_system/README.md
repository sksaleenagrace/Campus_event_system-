# Campus Event System

A comprehensive event management system for colleges with robust reporting capabilities. This system enables college administrators to create and manage events while providing students with an intuitive platform to discover, register for, and participate in campus activities.

## 🏗️ System Architecture

The Campus Event System consists of:
- **Admin Portal (Web)**: College staff create/manage events, view analytics
- **Student App (Mobile)**: Students browse events, register, mark attendance, provide feedback
- **Event Reporting System**: Comprehensive analytics and reporting capabilities

## 🛠️ Tech Stack

- **Backend**: FastAPI with Python 3.9+
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Authentication**: JWT-based authentication
- **API Documentation**: Automatic OpenAPI/Swagger documentation
- **Testing**: pytest with async support

## 📋 Features

### Admin Portal
- ✅ Event creation and management
- ✅ Student registration tracking
- ✅ Attendance monitoring
- ✅ Comprehensive reporting dashboard
- ✅ Multi-college support
- ✅ Role-based access control

### Student Experience
- ✅ Event discovery and browsing
- ✅ Easy registration process
- ✅ QR code-based check-in
- ✅ Feedback submission
- ✅ Personal event history

### Reporting System
- ✅ Registrations per event
- ✅ Attendance percentage analysis
- ✅ Average feedback scores
- ✅ Event popularity rankings
- ✅ Student participation metrics
- ✅ Top active students identification

## 🚀 Quick Start

### Prerequisites

- Python 3.9 or higher
- PostgreSQL 12 or higher
- pip (Python package manager)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd campus_event_system
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up PostgreSQL database**
   ```bash
   # Create database
   createdb campus_events
   
   # Run schema creation
   psql -d campus_events -f schema.sql
   ```

5. **Configure environment variables**
   Create a `.env` file in the root directory:
   ```env
   DATABASE_URL=postgresql://username:password@localhost/campus_events
   SECRET_KEY=your-secret-key-here
   ```

6. **Generate sample data (optional)**
   ```bash
   python -m src.sample_data
   ```

7. **Start the development server**
   ```bash
   python -m src.main
   ```

The API will be available at `http://localhost:8000`

## 📖 API Documentation

Once the server is running, you can access:
- **Interactive API Documentation**: http://localhost:8000/docs
- **ReDoc Documentation**: http://localhost:8000/redoc

### Authentication

All API endpoints (except login) require JWT authentication. Include the token in the Authorization header:

```bash
Authorization: Bearer <your-jwt-token>
```

### Sample API Calls

#### 1. Login
```bash
curl -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin_tu",
    "password": "password123"
  }'
```

#### 2. Create Event
```bash
curl -X POST "http://localhost:8000/api/v1/events/" \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Python Workshop",
    "description": "Learn Python programming basics",
    "event_type": "workshop",
    "start_time": "2024-04-15T10:00:00Z",
    "end_time": "2024-04-15T16:00:00Z",
    "venue": "Computer Lab 1",
    "max_capacity": 30
  }'
```

#### 3. Register Student for Event
```bash
curl -X POST "http://localhost:8000/api/v1/registrations/" \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "event_id": "event-uuid-here",
    "student_id": "student-uuid-here"
  }'
```

#### 4. Mark Attendance
```bash
curl -X POST "http://localhost:8000/api/v1/attendance/" \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "registration_id": "registration-uuid-here",
    "check_in_time": "2024-04-15T10:05:00Z"
  }'
```

#### 5. Generate Reports
```bash
# Event popularity report
curl -X GET "http://localhost:8000/api/v1/reports/event-popularity" \
  -H "Authorization: Bearer <token>"

# Attendance percentage report
curl -X GET "http://localhost:8000/api/v1/reports/attendance-percentage" \
  -H "Authorization: Bearer <token>"

# Top active students
curl -X GET "http://localhost:8000/api/v1/reports/top-active-students" \
  -H "Authorization: Bearer <token>"
```

## 🗄️ Database Schema

The system uses a normalized PostgreSQL database with the following main entities:

- **colleges**: Institution information
- **users**: Admin/staff authentication
- **students**: Student profiles
- **events**: Event details and scheduling
- **registrations**: Student event registrations
- **attendance**: Attendance tracking
- **feedback**: Event feedback and ratings

See `schema.sql` for complete table definitions and relationships.

## 📊 Sample Data

The system includes a comprehensive sample data generator that creates:
- 5 colleges with realistic information
- 100 students per college (500 total)
- 4 events per college with varied types
- Realistic registration patterns (60-90% capacity)
- Attendance records (85% attendance rate)
- Feedback submissions (70% feedback rate)

### Default Admin Credentials

After running the sample data script:
- **Tech University**: `admin_tu` / `password123`
- **Engineering College**: `admin_ec` / `password123`
- **Science Institute**: `admin_si` / `password123`
- **Business School**: `admin_bs` / `password123`
- **Arts College**: `admin_ac` / `password123`

## 📈 Reports Available

### 1. Registrations per Event
Shows registration statistics including total, active, cancelled registrations and capacity utilization.

### 2. Attendance Percentage
Analyzes attendance rates across all events with detailed breakdowns.

### 3. Average Feedback Score
Displays feedback statistics including rating distributions and average scores.

### 4. Event Popularity
Rankings based on registrations, attendance rates, and feedback scores.

### 5. Student Participation
Individual student activity metrics and engagement levels.

### 6. Top Active Students
Identifies the most engaged students across the platform.

All reports support filtering by:
- College
- Event type
- Date range
- Custom parameters

## 🧪 Testing

Run the test suite:
```bash
pytest
```

Run with coverage:
```bash
pytest --cov=src
```

## 🏗️ Project Structure

```
campus_event_system/
├── src/                          # Source code
│   ├── routers/                  # API route handlers
│   │   ├── events.py            # Event management endpoints
│   │   ├── students.py          # Student management endpoints
│   │   ├── registrations.py     # Registration endpoints
│   │   ├── attendance.py        # Attendance tracking endpoints
│   │   ├── feedback.py          # Feedback collection endpoints
│   │   └── reports.py           # Reporting endpoints
│   ├── models.py                # SQLAlchemy database models
│   ├── schemas.py               # Pydantic request/response schemas
│   ├── database.py              # Database configuration
│   ├── auth.py                  # Authentication utilities
│   ├── main.py                  # FastAPI application entry point
│   └── sample_data.py           # Sample data generator
├── reports/                      # Report queries and samples
│   ├── sample_queries.sql       # SQL queries for reports
│   └── sample_outputs.json      # Example report outputs
├── mockups/                      # UI wireframes and designs
│   └── ui_wireframes.md         # Detailed UI mockups
├── design_doc.md                # Comprehensive system design
├── schema.sql                   # Database schema and sample data
├── requirements.txt             # Python dependencies
└── README.md                    # This file
```

## 🔧 Configuration

### Environment Variables

- `DATABASE_URL`: PostgreSQL connection string
- `SECRET_KEY`: JWT signing secret (change in production)
- `ACCESS_TOKEN_EXPIRE_MINUTES`: Token expiration time (default: 60)

### Database Configuration

The system supports PostgreSQL with the following recommended settings:
- Connection pooling for production deployments
- Read replicas for report generation
- Proper indexing for performance optimization

## 🚀 Deployment

### Production Considerations

1. **Security**
   - Change default SECRET_KEY
   - Use environment variables for sensitive data
   - Enable HTTPS
   - Implement rate limiting

2. **Performance**
   - Configure database connection pooling
   - Use Redis for caching reports
   - Implement proper logging
   - Monitor API performance

3. **Scalability**
   - Use load balancers for multiple instances
   - Implement database read replicas
   - Consider microservices architecture for large deployments

### Docker Deployment (Optional)

Create a `Dockerfile`:
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
CMD ["python", "-m", "src.main"]
```

## 📱 Mobile App Integration

The API is designed to support mobile applications with:
- RESTful endpoints optimized for mobile consumption
- JWT authentication for secure access
- Efficient data pagination
- Real-time event updates support
- QR code-based check-in functionality

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Check the API documentation at `/docs`
- Review the design document for system architecture
- Examine sample queries in the `reports/` directory
- Test with the provided sample data

## 🔮 Future Enhancements

- Real-time notifications via WebSocket
- Advanced analytics with machine learning
- Calendar system integration
- Payment gateway for paid events
- Social media integration
- Mobile push notifications
- Multi-language support
- Advanced role-based permissions

---

## My Understanding of the System

*[This section is intentionally left as a placeholder for your personal understanding. The AI-generated content above provides a comprehensive technical overview, but you should replace this section with your own insights about the system's purpose, design decisions, and implementation approach based on your experience building and working with the Campus Event System.]*
