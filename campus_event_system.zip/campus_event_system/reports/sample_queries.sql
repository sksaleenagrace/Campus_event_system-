-- Campus Event System - Sample Report Queries
-- These queries demonstrate the reporting capabilities of the system

-- 1. Registrations per Event Report
-- Shows registration statistics for each event
SELECT 
    e.id as event_id,
    e.title as event_title,
    e.event_type,
    c.name as college_name,
    COUNT(r.id) as total_registrations,
    COUNT(CASE WHEN r.status = 'registered' THEN 1 END) as active_registrations,
    COUNT(CASE WHEN r.status = 'cancelled' THEN 1 END) as cancelled_registrations,
    CASE 
        WHEN e.max_capacity > 0 THEN 
            ROUND((COUNT(CASE WHEN r.status = 'registered' THEN 1 END)::DECIMAL / e.max_capacity) * 100, 2)
        ELSE 0 
    END as capacity_utilization_percent
FROM events e
JOIN colleges c ON e.college_id = c.id
LEFT JOIN registrations r ON e.id = r.event_id
WHERE e.is_active = true
GROUP BY e.id, e.title, e.event_type, c.name, e.max_capacity
ORDER BY total_registrations DESC;

-- 2. Attendance Percentage Report
-- Shows attendance rates for each event
SELECT 
    e.id as event_id,
    e.title as event_title,
    e.event_type,
    c.name as college_name,
    COUNT(DISTINCT r.id) as total_registrations,
    COUNT(DISTINCT a.id) as total_attendance,
    CASE 
        WHEN COUNT(DISTINCT r.id) > 0 THEN 
            ROUND((COUNT(DISTINCT a.id)::DECIMAL / COUNT(DISTINCT r.id)) * 100, 2)
        ELSE 0 
    END as attendance_percentage
FROM events e
JOIN colleges c ON e.college_id = c.id
LEFT JOIN registrations r ON e.id = r.event_id AND r.status = 'registered'
LEFT JOIN attendance a ON r.id = a.registration_id
WHERE e.is_active = true
GROUP BY e.id, e.title, e.event_type, c.name
HAVING COUNT(DISTINCT r.id) > 0
ORDER BY attendance_percentage DESC;

-- 3. Average Feedback Score Report
-- Shows feedback statistics for each event
SELECT 
    e.id as event_id,
    e.title as event_title,
    e.event_type,
    c.name as college_name,
    COUNT(f.id) as total_feedback,
    ROUND(AVG(f.rating), 2) as average_rating,
    COUNT(CASE WHEN f.rating = 5 THEN 1 END) as rating_5_count,
    COUNT(CASE WHEN f.rating = 4 THEN 1 END) as rating_4_count,
    COUNT(CASE WHEN f.rating = 3 THEN 1 END) as rating_3_count,
    COUNT(CASE WHEN f.rating = 2 THEN 1 END) as rating_2_count,
    COUNT(CASE WHEN f.rating = 1 THEN 1 END) as rating_1_count
FROM events e
JOIN colleges c ON e.college_id = c.id
JOIN registrations r ON e.id = r.event_id
JOIN attendance a ON r.id = a.registration_id
JOIN feedback f ON a.id = f.attendance_id
WHERE e.is_active = true
GROUP BY e.id, e.title, e.event_type, c.name
ORDER BY average_rating DESC, total_feedback DESC;

-- 4. Event Popularity Report
-- Ranks events by total registrations and engagement
SELECT 
    ROW_NUMBER() OVER (ORDER BY COUNT(DISTINCT r.id) DESC, AVG(f.rating) DESC) as rank,
    e.id as event_id,
    e.title as event_title,
    e.event_type,
    c.name as college_name,
    COUNT(DISTINCT r.id) as total_registrations,
    COUNT(DISTINCT a.id) as total_attendance,
    CASE 
        WHEN COUNT(DISTINCT r.id) > 0 THEN 
            ROUND((COUNT(DISTINCT a.id)::DECIMAL / COUNT(DISTINCT r.id)) * 100, 2)
        ELSE 0 
    END as attendance_rate,
    ROUND(AVG(f.rating), 2) as average_rating
FROM events e
JOIN colleges c ON e.college_id = c.id
LEFT JOIN registrations r ON e.id = r.event_id AND r.status = 'registered'
LEFT JOIN attendance a ON r.id = a.registration_id
LEFT JOIN feedback f ON a.id = f.attendance_id
WHERE e.is_active = true
GROUP BY e.id, e.title, e.event_type, c.name
HAVING COUNT(DISTINCT r.id) > 0
ORDER BY total_registrations DESC, average_rating DESC
LIMIT 10;

-- 5. Student Participation Report
-- Shows participation statistics for each student
SELECT 
    s.id as student_id,
    s.first_name || ' ' || s.last_name as student_name,
    s.email,
    c.name as college_name,
    s.department,
    s.year,
    COUNT(DISTINCT r.id) as total_registrations,
    COUNT(DISTINCT a.id) as events_attended,
    CASE 
        WHEN COUNT(DISTINCT r.id) > 0 THEN 
            ROUND((COUNT(DISTINCT a.id)::DECIMAL / COUNT(DISTINCT r.id)) * 100, 2)
        ELSE 0 
    END as attendance_rate,
    ROUND(AVG(f.rating), 2) as average_rating_given
FROM students s
JOIN colleges c ON s.college_id = c.id
LEFT JOIN registrations r ON s.id = r.student_id AND r.status = 'registered'
LEFT JOIN attendance a ON r.id = a.registration_id
LEFT JOIN feedback f ON a.id = f.attendance_id
GROUP BY s.id, s.first_name, s.last_name, s.email, c.name, s.department, s.year
HAVING COUNT(DISTINCT r.id) > 0
ORDER BY events_attended DESC, attendance_rate DESC;

-- 6. Top Active Students Report
-- Shows the most active students across all colleges
SELECT 
    ROW_NUMBER() OVER (ORDER BY COUNT(DISTINCT a.id) DESC, AVG(f.rating) DESC) as rank,
    s.id as student_id,
    s.first_name || ' ' || s.last_name as student_name,
    c.name as college_name,
    s.department,
    COUNT(DISTINCT a.id) as events_attended,
    COUNT(DISTINCT f.id) as feedback_given,
    ROUND(AVG(f.rating), 2) as average_rating_given
FROM students s
JOIN colleges c ON s.college_id = c.id
JOIN registrations r ON s.id = r.student_id AND r.status = 'registered'
JOIN attendance a ON r.id = a.registration_id
LEFT JOIN feedback f ON a.id = f.attendance_id
GROUP BY s.id, s.first_name, s.last_name, c.name, s.department
ORDER BY events_attended DESC, average_rating_given DESC
LIMIT 10;

-- 7. College Performance Report
-- Compares performance across different colleges
SELECT 
    c.id as college_id,
    c.name as college_name,
    c.code,
    COUNT(DISTINCT s.id) as total_students,
    COUNT(DISTINCT e.id) as total_events,
    COUNT(DISTINCT r.id) as total_registrations,
    COUNT(DISTINCT a.id) as total_attendance,
    COUNT(DISTINCT f.id) as total_feedback,
    CASE 
        WHEN COUNT(DISTINCT r.id) > 0 THEN 
            ROUND((COUNT(DISTINCT a.id)::DECIMAL / COUNT(DISTINCT r.id)) * 100, 2)
        ELSE 0 
    END as overall_attendance_rate,
    ROUND(AVG(f.rating), 2) as average_feedback_score
FROM colleges c
LEFT JOIN students s ON c.id = s.college_id
LEFT JOIN events e ON c.id = e.college_id AND e.is_active = true
LEFT JOIN registrations r ON e.id = r.event_id AND r.status = 'registered'
LEFT JOIN attendance a ON r.id = a.registration_id
LEFT JOIN feedback f ON a.id = f.attendance_id
GROUP BY c.id, c.name, c.code
ORDER BY total_events DESC, overall_attendance_rate DESC;

-- 8. Event Type Analysis
-- Analyzes performance by event type
SELECT 
    e.event_type,
    COUNT(DISTINCT e.id) as total_events,
    COUNT(DISTINCT r.id) as total_registrations,
    COUNT(DISTINCT a.id) as total_attendance,
    ROUND(AVG(e.max_capacity), 0) as avg_capacity,
    CASE 
        WHEN COUNT(DISTINCT r.id) > 0 THEN 
            ROUND((COUNT(DISTINCT a.id)::DECIMAL / COUNT(DISTINCT r.id)) * 100, 2)
        ELSE 0 
    END as attendance_rate,
    ROUND(AVG(f.rating), 2) as average_rating
FROM events e
LEFT JOIN registrations r ON e.id = r.event_id AND r.status = 'registered'
LEFT JOIN attendance a ON r.id = a.registration_id
LEFT JOIN feedback f ON a.id = f.attendance_id
WHERE e.is_active = true
GROUP BY e.event_type
ORDER BY total_events DESC;

-- 9. Monthly Event Trends
-- Shows event activity trends by month
SELECT 
    DATE_TRUNC('month', e.start_time) as month,
    COUNT(DISTINCT e.id) as events_count,
    COUNT(DISTINCT r.id) as registrations_count,
    COUNT(DISTINCT a.id) as attendance_count,
    ROUND(AVG(f.rating), 2) as avg_rating
FROM events e
LEFT JOIN registrations r ON e.id = r.event_id AND r.status = 'registered'
LEFT JOIN attendance a ON r.id = a.registration_id
LEFT JOIN feedback f ON a.id = f.attendance_id
WHERE e.is_active = true
GROUP BY DATE_TRUNC('month', e.start_time)
ORDER BY month;

-- 10. Detailed Event Report (for specific event)
-- Replace the UUID with actual event ID
SELECT 
    e.title,
    e.description,
    e.event_type,
    c.name as college_name,
    e.start_time,
    e.end_time,
    e.venue,
    e.max_capacity,
    COUNT(DISTINCT r.id) as total_registrations,
    COUNT(DISTINCT CASE WHEN r.status = 'registered' THEN r.id END) as active_registrations,
    COUNT(DISTINCT a.id) as total_attendance,
    COUNT(DISTINCT f.id) as feedback_count,
    ROUND(AVG(f.rating), 2) as average_rating,
    STRING_AGG(DISTINCT s.department, ', ') as departments_represented
FROM events e
JOIN colleges c ON e.college_id = c.id
LEFT JOIN registrations r ON e.id = r.event_id
LEFT JOIN students s ON r.student_id = s.id
LEFT JOIN attendance a ON r.id = a.registration_id
LEFT JOIN feedback f ON a.id = f.attendance_id
WHERE e.id = '550e8400-e29b-41d4-a716-446655440030'  -- Replace with actual event ID
GROUP BY e.id, e.title, e.description, e.event_type, c.name, e.start_time, e.end_time, e.venue, e.max_capacity;
