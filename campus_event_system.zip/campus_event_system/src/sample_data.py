"""
Sample data generation script for Campus Event System
This script creates realistic sample data for testing the system
"""

import asyncio
from datetime import datetime, timedelta
from uuid import uuid4
from sqlalchemy.orm import Session
from src.database import SessionLocal, engine
from src.models import Base, College, User, Student, Event, Registration, Attendance, Feedback
from src.models import EventType, UserRole, RegistrationStatus
from src.auth import get_password_hash
import random

# Sample data
COLLEGES_DATA = [
    {
        "name": "Tech University",
        "code": "TU",
        "address": "123 Tech Street, Silicon Valley, CA",
        "contact_email": "admin@techuni.edu",
        "contact_phone": "+1-555-0101"
    },
    {
        "name": "Engineering College",
        "code": "EC",
        "address": "456 Engineering Ave, Tech City, TX",
        "contact_email": "info@engcollege.edu",
        "contact_phone": "+1-555-0102"
    },
    {
        "name": "Science Institute",
        "code": "SI",
        "address": "789 Science Blvd, Research Park, NY",
        "contact_email": "contact@sciinst.edu",
        "contact_phone": "+1-555-0103"
    },
    {
        "name": "Business School",
        "code": "BS",
        "address": "321 Business Center, Finance District, IL",
        "contact_email": "admin@bizschool.edu",
        "contact_phone": "+1-555-0104"
    },
    {
        "name": "Arts College",
        "code": "AC",
        "address": "654 Creative Lane, Art Quarter, CA",
        "contact_email": "info@artscollege.edu",
        "contact_phone": "+1-555-0105"
    }
]

DEPARTMENTS = [
    "Computer Science", "Data Science", "Software Engineering", "Information Technology",
    "Mechanical Engineering", "Electrical Engineering", "Civil Engineering", "Chemical Engineering",
    "Physics", "Chemistry", "Biology", "Mathematics", "Statistics",
    "Business Administration", "Marketing", "Finance", "Economics",
    "Fine Arts", "Music", "Literature", "Philosophy"
]

FIRST_NAMES = [
    "John", "Jane", "Mike", "Sarah", "David", "Emily", "Chris", "Lisa",
    "Alex", "Maria", "James", "Anna", "Robert", "Jessica", "Michael", "Ashley",
    "Daniel", "Amanda", "Kevin", "Rachel", "Brian", "Nicole", "Steven", "Michelle",
    "Andrew", "Stephanie", "Joshua", "Elizabeth", "Matthew", "Jennifer"
]

LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas",
    "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White",
    "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson"
]

EVENT_TEMPLATES = [
    {
        "title": "AI/ML Workshop",
        "description": "Hands-on workshop covering machine learning fundamentals and practical applications",
        "event_type": EventType.workshop,
        "duration_hours": 6,
        "max_capacity": 50
    },
    {
        "title": "Tech Fest 2024",
        "description": "Annual technology festival featuring competitions, exhibitions, and networking",
        "event_type": EventType.fest,
        "duration_hours": 72,
        "max_capacity": 500
    },
    {
        "title": "Robotics Seminar",
        "description": "Exploring the latest trends in robotics and automation technology",
        "event_type": EventType.seminar,
        "duration_hours": 3,
        "max_capacity": 100
    },
    {
        "title": "Quantum Computing Hackathon",
        "description": "48-hour intensive hackathon focusing on quantum algorithms and applications",
        "event_type": EventType.hackathon,
        "duration_hours": 48,
        "max_capacity": 30
    },
    {
        "title": "Data Science Workshop",
        "description": "Comprehensive workshop on data analysis, visualization, and statistical modeling",
        "event_type": EventType.workshop,
        "duration_hours": 8,
        "max_capacity": 40
    },
    {
        "title": "Cybersecurity Seminar",
        "description": "Understanding modern cybersecurity threats and defense strategies",
        "event_type": EventType.seminar,
        "duration_hours": 4,
        "max_capacity": 80
    },
    {
        "title": "Innovation Challenge",
        "description": "Competition for innovative solutions to real-world problems",
        "event_type": EventType.hackathon,
        "duration_hours": 24,
        "max_capacity": 60
    },
    {
        "title": "Web Development Bootcamp",
        "description": "Intensive bootcamp covering full-stack web development",
        "event_type": EventType.workshop,
        "duration_hours": 16,
        "max_capacity": 35
    }
]

VENUES = [
    "Computer Lab 1", "Computer Lab 2", "Main Auditorium", "Seminar Hall A", 
    "Seminar Hall B", "Innovation Lab", "Conference Room 1", "Conference Room 2",
    "Lecture Hall 1", "Lecture Hall 2", "Workshop Room", "Exhibition Hall"
]

FEEDBACK_COMMENTS = [
    "Excellent workshop! Very informative and well-structured.",
    "Great hands-on experience. The instructor was knowledgeable.",
    "Good content but could use more interactive elements.",
    "Well organized event with practical examples.",
    "Learned a lot of new concepts. Would recommend to others.",
    "The pace was perfect and examples were relevant.",
    "Could have been longer to cover more advanced topics.",
    "Excellent networking opportunities and great speakers.",
    "Very engaging and interactive session.",
    "Good introduction to the topic but needs more depth."
]

def create_sample_data():
    """Create comprehensive sample data for the system"""
    
    # Create tables
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    
    try:
        # Clear existing data (for development only)
        print("Clearing existing data...")
        db.query(Feedback).delete()
        db.query(Attendance).delete()
        db.query(Registration).delete()
        db.query(Event).delete()
        db.query(Student).delete()
        db.query(User).delete()
        db.query(College).delete()
        db.commit()
        
        # Create colleges
        print("Creating colleges...")
        colleges = []
        for college_data in COLLEGES_DATA:
            college = College(**college_data)
            db.add(college)
            colleges.append(college)
        db.commit()
        
        # Create admin users for each college
        print("Creating admin users...")
        users = []
        password_hash = get_password_hash("password123")
        
        for college in colleges:
            user = User(
                college_id=college.id,
                username=f"admin_{college.code.lower()}",
                email=f"admin@{college.code.lower()}.edu",
                password_hash=password_hash,
                role=UserRole.admin
            )
            db.add(user)
            users.append(user)
        db.commit()
        
        # Create students (100 per college)
        print("Creating students...")
        students = []
        for college in colleges:
            for i in range(100):
                first_name = random.choice(FIRST_NAMES)
                last_name = random.choice(LAST_NAMES)
                student = Student(
                    college_id=college.id,
                    student_id=f"{college.code}{2024}{i+1:03d}",
                    first_name=first_name,
                    last_name=last_name,
                    email=f"{first_name.lower()}.{last_name.lower()}{i+1}@student.{college.code.lower()}.edu",
                    phone=f"+1-555-{random.randint(1000, 9999)}",
                    department=random.choice(DEPARTMENTS),
                    year=random.randint(1, 4)
                )
                db.add(student)
                students.append(student)
        db.commit()
        
        # Create events (4 per college, spanning different dates)
        print("Creating events...")
        events = []
        base_date = datetime(2024, 3, 1)
        
        for college in colleges:
            for i, template in enumerate(EVENT_TEMPLATES[:4]):  # 4 events per college
                start_time = base_date + timedelta(days=i*7 + random.randint(0, 6))
                end_time = start_time + timedelta(hours=template["duration_hours"])
                
                event = Event(
                    college_id=college.id,
                    title=f"{template['title']} - {college.name}",
                    description=template["description"],
                    event_type=template["event_type"],
                    start_time=start_time,
                    end_time=end_time,
                    venue=random.choice(VENUES),
                    max_capacity=template["max_capacity"]
                )
                db.add(event)
                events.append(event)
        db.commit()
        
        # Create registrations (random selection of students for each event)
        print("Creating registrations...")
        registrations = []
        
        for event in events:
            # Get students from the same college
            college_students = [s for s in students if s.college_id == event.college_id]
            
            # Register 60-90% of capacity or available students
            num_registrations = min(
                len(college_students),
                random.randint(
                    int(event.max_capacity * 0.6),
                    int(event.max_capacity * 0.9)
                )
            )
            
            selected_students = random.sample(college_students, num_registrations)
            
            for student in selected_students:
                # 95% registered, 5% cancelled
                status = RegistrationStatus.cancelled if random.random() < 0.05 else RegistrationStatus.registered
                
                registration = Registration(
                    event_id=event.id,
                    student_id=student.id,
                    registration_time=event.start_time - timedelta(days=random.randint(1, 14)),
                    status=status
                )
                db.add(registration)
                registrations.append(registration)
        db.commit()
        
        # Create attendance records (80-95% of registered students attend)
        print("Creating attendance records...")
        attendances = []
        
        registered_registrations = [r for r in registrations if r.status == RegistrationStatus.registered]
        
        for registration in registered_registrations:
            if random.random() < 0.85:  # 85% attendance rate
                event = next(e for e in events if e.id == registration.event_id)
                
                # Check-in time: 0-30 minutes after event start
                check_in_time = event.start_time + timedelta(minutes=random.randint(0, 30))
                
                # Check-out time: 0-30 minutes before event end (80% check out)
                check_out_time = None
                if random.random() < 0.8:
                    check_out_time = event.end_time - timedelta(minutes=random.randint(0, 30))
                
                attendance = Attendance(
                    registration_id=registration.id,
                    check_in_time=check_in_time,
                    check_out_time=check_out_time,
                    notes="Attended event" if random.random() < 0.7 else None
                )
                db.add(attendance)
                attendances.append(attendance)
        db.commit()
        
        # Create feedback (70% of attendees provide feedback)
        print("Creating feedback records...")
        
        for attendance in attendances:
            if random.random() < 0.7:  # 70% feedback rate
                rating = random.choices(
                    [1, 2, 3, 4, 5],
                    weights=[2, 5, 15, 40, 38]  # Skewed towards positive ratings
                )[0]
                
                comments = random.choice(FEEDBACK_COMMENTS) if random.random() < 0.8 else None
                
                feedback_data = {
                    "content_quality": random.randint(3, 5),
                    "instructor_rating": random.randint(3, 5),
                    "venue_rating": random.randint(2, 5),
                    "would_recommend": random.random() < 0.8
                }
                
                feedback = Feedback(
                    attendance_id=attendance.id,
                    rating=rating,
                    comments=comments,
                    feedback_data=feedback_data
                )
                db.add(feedback)
        
        db.commit()
        
        print("\n✅ Sample data created successfully!")
        print(f"Created:")
        print(f"  - {len(colleges)} colleges")
        print(f"  - {len(users)} admin users")
        print(f"  - {len(students)} students")
        print(f"  - {len(events)} events")
        print(f"  - {len(registrations)} registrations")
        print(f"  - {len(attendances)} attendance records")
        print(f"  - Feedback records for ~70% of attendees")
        
        print(f"\nDefault admin credentials:")
        for college in colleges:
            print(f"  {college.name}: admin_{college.code.lower()} / password123")
        
    except Exception as e:
        print(f"Error creating sample data: {e}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    create_sample_data()
