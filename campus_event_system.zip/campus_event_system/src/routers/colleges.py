from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID
from ..database import get_db
from ..models import College
from ..schemas import College as CollegeSchema, CollegeCreate
from ..auth import get_current_active_user

router = APIRouter()

@router.post("/", response_model=CollegeSchema, status_code=status.HTTP_201_CREATED)
def create_college(
    college: CollegeCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Create a new college."""
    # Check if college code already exists
    existing_college = db.query(College).filter(College.code == college.code).first()
    if existing_college:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="College with this code already exists"
        )
    
    db_college = College(**college.dict())
    db.add(db_college)
    db.commit()
    db.refresh(db_college)
    return db_college

@router.get("/", response_model=List[CollegeSchema])
def get_colleges(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get all colleges."""
    colleges = db.query(College).offset(skip).limit(limit).all()
    return colleges

@router.get("/{college_id}", response_model=CollegeSchema)
def get_college(
    college_id: UUID,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get a specific college by ID."""
    college = db.query(College).filter(College.id == college_id).first()
    if not college:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="College not found"
        )
    return college
