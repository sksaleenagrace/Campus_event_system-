from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from uuid import UUID
from ..database import get_db
from ..models import Feedback, Attendance
from ..schemas import Feedback as FeedbackSchema, FeedbackCreate
from ..auth import get_current_active_user

router = APIRouter()

@router.post("/", response_model=FeedbackSchema, status_code=status.HTTP_201_CREATED)
def create_feedback(
    feedback: FeedbackCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Submit feedback for an attended event."""
    # Check if attendance record exists
    attendance = db.query(Attendance).filter(Attendance.id == feedback.attendance_id).first()
    if not attendance:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Attendance record not found"
        )
    
    # Check if feedback already exists
    existing_feedback = db.query(Feedback).filter(
        Feedback.attendance_id == feedback.attendance_id
    ).first()
    if existing_feedback:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Feedback already submitted for this attendance"
        )
    
    db_feedback = Feedback(**feedback.dict())
    db.add(db_feedback)
    db.commit()
    db.refresh(db_feedback)
    return db_feedback

@router.get("/", response_model=List[FeedbackSchema])
def get_feedback_records(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    event_id: Optional[UUID] = None,
    student_id: Optional[UUID] = None,
    rating: Optional[int] = Query(None, ge=1, le=5),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get feedback records with optional filters."""
    query = db.query(Feedback).join(Attendance).join(Attendance.registration)
    
    # Apply filters
    if event_id:
        query = query.filter(Attendance.registration.has(event_id=event_id))
    if student_id:
        query = query.filter(Attendance.registration.has(student_id=student_id))
    if rating:
        query = query.filter(Feedback.rating == rating)
    
    feedback_records = query.offset(skip).limit(limit).all()
    return feedback_records

@router.get("/{feedback_id}", response_model=FeedbackSchema)
def get_feedback(
    feedback_id: UUID,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get a specific feedback record by ID."""
    feedback = db.query(Feedback).filter(Feedback.id == feedback_id).first()
    if not feedback:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Feedback record not found"
        )
    return feedback

@router.get("/events/{event_id}/feedback", response_model=List[FeedbackSchema])
def get_event_feedback(
    event_id: UUID,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get all feedback for a specific event."""
    feedback_records = db.query(Feedback).join(Attendance).join(Attendance.registration).filter(
        Attendance.registration.has(event_id=event_id)
    ).offset(skip).limit(limit).all()
    return feedback_records
