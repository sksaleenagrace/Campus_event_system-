from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from uuid import UUID
from datetime import datetime
from ..database import get_db
from ..models import Attendance, Registration, RegistrationStatus
from ..schemas import Attendance as AttendanceSchema, AttendanceCreate, AttendanceUpdate
from ..auth import get_current_active_user

router = APIRouter()

@router.post("/", response_model=AttendanceSchema, status_code=status.HTTP_201_CREATED)
def mark_attendance(
    attendance: AttendanceCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Mark attendance for a registered student."""
    # Check if registration exists and is active
    registration = db.query(Registration).filter(
        Registration.id == attendance.registration_id,
        Registration.status == RegistrationStatus.registered
    ).first()
    if not registration:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Valid registration not found"
        )
    
    # Check if attendance already exists
    existing_attendance = db.query(Attendance).filter(
        Attendance.registration_id == attendance.registration_id
    ).first()
    if existing_attendance:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Attendance already marked for this registration"
        )
    
    # Validate check-in time is not in the future
    if attendance.check_in_time > datetime.utcnow():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Check-in time cannot be in the future"
        )
    
    db_attendance = Attendance(**attendance.dict())
    db.add(db_attendance)
    db.commit()
    db.refresh(db_attendance)
    return db_attendance

@router.get("/", response_model=List[AttendanceSchema])
def get_attendance_records(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    event_id: Optional[UUID] = None,
    student_id: Optional[UUID] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get attendance records with optional filters."""
    query = db.query(Attendance).join(Registration)
    
    # Apply filters
    if event_id:
        query = query.filter(Registration.event_id == event_id)
    if student_id:
        query = query.filter(Registration.student_id == student_id)
    
    attendance_records = query.offset(skip).limit(limit).all()
    return attendance_records

@router.get("/{attendance_id}", response_model=AttendanceSchema)
def get_attendance(
    attendance_id: UUID,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get a specific attendance record by ID."""
    attendance = db.query(Attendance).filter(Attendance.id == attendance_id).first()
    if not attendance:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Attendance record not found"
        )
    return attendance

@router.put("/{attendance_id}/checkout", response_model=AttendanceSchema)
def checkout_attendance(
    attendance_id: UUID,
    checkout_data: AttendanceUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Update attendance record with checkout time."""
    attendance = db.query(Attendance).filter(Attendance.id == attendance_id).first()
    if not attendance:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Attendance record not found"
        )
    
    # Validate checkout time
    if checkout_data.check_out_time:
        if checkout_data.check_out_time <= attendance.check_in_time:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Check-out time must be after check-in time"
            )
        if checkout_data.check_out_time > datetime.utcnow():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Check-out time cannot be in the future"
            )
    
    # Update fields
    update_data = checkout_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(attendance, field, value)
    
    db.commit()
    db.refresh(attendance)
    return attendance

@router.get("/events/{event_id}/attendance", response_model=List[AttendanceSchema])
def get_event_attendance(
    event_id: UUID,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get all attendance records for a specific event."""
    attendance_records = db.query(Attendance).join(Registration).filter(
        Registration.event_id == event_id
    ).offset(skip).limit(limit).all()
    return attendance_records
