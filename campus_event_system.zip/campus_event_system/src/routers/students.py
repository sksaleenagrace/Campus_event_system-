from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from uuid import UUID
from ..database import get_db
from ..models import Student
from ..schemas import Student as StudentSchema, StudentCreate
from ..auth import get_current_active_user

router = APIRouter()

@router.post("/", response_model=StudentSchema, status_code=status.HTTP_201_CREATED)
def create_student(
    student: StudentCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Create a new student."""
    # Check if email already exists
    existing_student = db.query(Student).filter(Student.email == student.email).first()
    if existing_student:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Student with this email already exists"
        )
    
    # Check if student_id already exists in the same college
    existing_student_id = db.query(Student).filter(
        Student.college_id == student.college_id,
        Student.student_id == student.student_id
    ).first()
    if existing_student_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Student ID already exists in this college"
        )
    
    db_student = Student(**student.dict())
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return db_student

@router.get("/", response_model=List[StudentSchema])
def get_students(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    college_id: Optional[UUID] = None,
    department: Optional[str] = None,
    year: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get students with optional filters."""
    query = db.query(Student)
    
    # Apply filters
    if college_id:
        query = query.filter(Student.college_id == college_id)
    if department:
        query = query.filter(Student.department.ilike(f"%{department}%"))
    if year:
        query = query.filter(Student.year == year)
    
    students = query.offset(skip).limit(limit).all()
    return students

@router.get("/{student_id}", response_model=StudentSchema)
def get_student(
    student_id: UUID,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get a specific student by ID."""
    student = db.query(Student).filter(Student.id == student_id).first()
    if not student:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Student not found"
        )
    return student

@router.get("/by-email/{email}", response_model=StudentSchema)
def get_student_by_email(
    email: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get a student by email address."""
    student = db.query(Student).filter(Student.email == email).first()
    if not student:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Student not found"
        )
    return student
