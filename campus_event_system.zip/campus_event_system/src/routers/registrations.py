from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_
from typing import List, Optional
from uuid import UUID
from ..database import get_db
from ..models import Registration, Event, Student, RegistrationStatus
from ..schemas import Registration as RegistrationSchema, RegistrationCreate
from ..auth import get_current_active_user

router = APIRouter()

@router.post("/", response_model=RegistrationSchema, status_code=status.HTTP_201_CREATED)
def create_registration(
    registration: RegistrationCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Register a student for an event."""
    # Check if event exists and is active
    event = db.query(Event).filter(Event.id == registration.event_id, Event.is_active == True).first()
    if not event:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Event not found or inactive"
        )
    
    # Check if student exists
    student = db.query(Student).filter(Student.id == registration.student_id).first()
    if not student:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Student not found"
        )
    
    # Check if already registered
    existing_registration = db.query(Registration).filter(
        and_(
            Registration.event_id == registration.event_id,
            Registration.student_id == registration.student_id
        )
    ).first()
    if existing_registration:
        if existing_registration.status == RegistrationStatus.registered:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Student already registered for this event"
            )
        elif existing_registration.status == RegistrationStatus.cancelled:
            # Reactivate cancelled registration
            existing_registration.status = RegistrationStatus.registered
            db.commit()
            db.refresh(existing_registration)
            return existing_registration
    
    # Check capacity if max_capacity is set
    if event.max_capacity:
        current_registrations = db.query(Registration).filter(
            and_(
                Registration.event_id == registration.event_id,
                Registration.status == RegistrationStatus.registered
            )
        ).count()
        
        if current_registrations >= event.max_capacity:
            # Create waitlisted registration
            db_registration = Registration(
                **registration.dict(),
                status=RegistrationStatus.waitlisted
            )
            db.add(db_registration)
            db.commit()
            db.refresh(db_registration)
            return db_registration
    
    # Create successful registration
    db_registration = Registration(**registration.dict())
    db.add(db_registration)
    db.commit()
    db.refresh(db_registration)
    return db_registration

@router.get("/", response_model=List[RegistrationSchema])
def get_registrations(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    event_id: Optional[UUID] = None,
    student_id: Optional[UUID] = None,
    status: Optional[RegistrationStatus] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get registrations with optional filters."""
    query = db.query(Registration)
    
    # Apply filters
    if event_id:
        query = query.filter(Registration.event_id == event_id)
    if student_id:
        query = query.filter(Registration.student_id == student_id)
    if status:
        query = query.filter(Registration.status == status)
    
    registrations = query.offset(skip).limit(limit).all()
    return registrations

@router.get("/{registration_id}", response_model=RegistrationSchema)
def get_registration(
    registration_id: UUID,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get a specific registration by ID."""
    registration = db.query(Registration).filter(Registration.id == registration_id).first()
    if not registration:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Registration not found"
        )
    return registration

@router.put("/{registration_id}/cancel")
def cancel_registration(
    registration_id: UUID,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Cancel a registration."""
    registration = db.query(Registration).filter(Registration.id == registration_id).first()
    if not registration:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Registration not found"
        )
    
    if registration.status == RegistrationStatus.cancelled:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Registration already cancelled"
        )
    
    registration.status = RegistrationStatus.cancelled
    db.commit()
    
    # Check if there are waitlisted students to promote
    waitlisted = db.query(Registration).filter(
        and_(
            Registration.event_id == registration.event_id,
            Registration.status == RegistrationStatus.waitlisted
        )
    ).order_by(Registration.registration_time).first()
    
    if waitlisted:
        waitlisted.status = RegistrationStatus.registered
        db.commit()
    
    return {"message": "Registration cancelled successfully"}

@router.get("/events/{event_id}/registrations", response_model=List[RegistrationSchema])
def get_event_registrations(
    event_id: UUID,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Get all registrations for a specific event."""
    registrations = db.query(Registration).filter(
        Registration.event_id == event_id
    ).offset(skip).limit(limit).all()
    return registrations
