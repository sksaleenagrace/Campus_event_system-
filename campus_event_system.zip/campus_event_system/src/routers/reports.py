from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, desc, and_
from typing import List, Optional, Dict, Any
from uuid import UUID
from datetime import datetime, date
from ..database import get_db
from ..models import (
    Event, Student, Registration, Attendance, Feedback, College,
    EventType, RegistrationStatus
)
from ..schemas import ReportResponse
from ..auth import get_current_active_user

router = APIRouter()

@router.get("/registrations-per-event")
def get_registrations_per_event_report(
    college_id: Optional[UUID] = None,
    event_type: Optional[EventType] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Generate registrations per event report."""
    query = db.query(
        Event.id.label('event_id'),
        Event.title.label('event_title'),
        Event.event_type,
        College.name.label('college_name'),
        func.count(Registration.id).label('total_registrations'),
        func.count(
            func.case([(Registration.status == RegistrationStatus.registered, 1)])
        ).label('active_registrations'),
        func.count(
            func.case([(Registration.status == RegistrationStatus.cancelled, 1)])
        ).label('cancelled_registrations'),
        Event.max_capacity
    ).select_from(Event)\
     .join(College, Event.college_id == College.id)\
     .outerjoin(Registration, Event.id == Registration.event_id)\
     .group_by(Event.id, Event.title, Event.event_type, College.name, Event.max_capacity)
    
    # Apply filters
    if college_id:
        query = query.filter(Event.college_id == college_id)
    if event_type:
        query = query.filter(Event.event_type == event_type)
    if start_date:
        query = query.filter(Event.start_time >= start_date)
    if end_date:
        query = query.filter(Event.start_time <= end_date)
    
    results = query.all()
    
    data = []
    for row in results:
        capacity_utilization = 0.0
        if row.max_capacity and row.max_capacity > 0:
            capacity_utilization = (row.active_registrations / row.max_capacity) * 100
        
        data.append({
            "event_id": row.event_id,
            "event_title": row.event_title,
            "event_type": row.event_type,
            "college_name": row.college_name,
            "total_registrations": row.total_registrations,
            "active_registrations": row.active_registrations,
            "cancelled_registrations": row.cancelled_registrations,
            "capacity_utilization": round(capacity_utilization, 2)
        })
    
    return {
        "report_type": "registrations_per_event",
        "generated_at": datetime.utcnow(),
        "data": data,
        "total": len(data),
        "filters": {
            "college_id": str(college_id) if college_id else None,
            "event_type": event_type,
            "start_date": start_date.isoformat() if start_date else None,
            "end_date": end_date.isoformat() if end_date else None
        }
    }

@router.get("/attendance-percentage")
def get_attendance_percentage_report(
    college_id: Optional[UUID] = None,
    event_type: Optional[EventType] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Generate attendance percentage report."""
    query = db.query(
        Event.id.label('event_id'),
        Event.title.label('event_title'),
        func.count(Registration.id).label('total_registrations'),
        func.count(Attendance.id).label('total_attendance')
    ).select_from(Event)\
     .outerjoin(Registration, and_(
         Event.id == Registration.event_id,
         Registration.status == RegistrationStatus.registered
     ))\
     .outerjoin(Attendance, Registration.id == Attendance.registration_id)\
     .group_by(Event.id, Event.title)
    
    # Apply filters
    if college_id:
        query = query.filter(Event.college_id == college_id)
    if event_type:
        query = query.filter(Event.event_type == event_type)
    if start_date:
        query = query.filter(Event.start_time >= start_date)
    if end_date:
        query = query.filter(Event.start_time <= end_date)
    
    results = query.all()
    
    data = []
    for row in results:
        attendance_percentage = 0.0
        if row.total_registrations > 0:
            attendance_percentage = (row.total_attendance / row.total_registrations) * 100
        
        data.append({
            "event_id": row.event_id,
            "event_title": row.event_title,
            "total_registrations": row.total_registrations,
            "total_attendance": row.total_attendance,
            "attendance_percentage": round(attendance_percentage, 2)
        })
    
    return {
        "report_type": "attendance_percentage",
        "generated_at": datetime.utcnow(),
        "data": data,
        "total": len(data)
    }

@router.get("/average-feedback-score")
def get_average_feedback_score_report(
    college_id: Optional[UUID] = None,
    event_type: Optional[EventType] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Generate average feedback score report."""
    query = db.query(
        Event.id.label('event_id'),
        Event.title.label('event_title'),
        func.count(Feedback.id).label('total_feedback'),
        func.avg(Feedback.rating).label('average_rating')
    ).select_from(Event)\
     .join(Registration, Event.id == Registration.event_id)\
     .join(Attendance, Registration.id == Attendance.registration_id)\
     .join(Feedback, Attendance.id == Feedback.attendance_id)\
     .group_by(Event.id, Event.title)
    
    # Apply filters
    if college_id:
        query = query.filter(Event.college_id == college_id)
    if event_type:
        query = query.filter(Event.event_type == event_type)
    if start_date:
        query = query.filter(Event.start_time >= start_date)
    if end_date:
        query = query.filter(Event.start_time <= end_date)
    
    results = query.all()
    
    data = []
    for row in results:
        # Get rating distribution
        rating_dist_query = db.query(
            Feedback.rating,
            func.count(Feedback.rating).label('count')
        ).join(Attendance, Feedback.attendance_id == Attendance.id)\
         .join(Registration, Attendance.registration_id == Registration.id)\
         .filter(Registration.event_id == row.event_id)\
         .group_by(Feedback.rating)
        
        rating_distribution = {str(i): 0 for i in range(1, 6)}
        for rating_row in rating_dist_query.all():
            rating_distribution[str(rating_row.rating)] = rating_row.count
        
        data.append({
            "event_id": row.event_id,
            "event_title": row.event_title,
            "total_feedback": row.total_feedback,
            "average_rating": round(float(row.average_rating), 2) if row.average_rating else 0.0,
            "rating_distribution": rating_distribution
        })
    
    return {
        "report_type": "average_feedback_score",
        "generated_at": datetime.utcnow(),
        "data": data,
        "total": len(data)
    }

@router.get("/event-popularity")
def get_event_popularity_report(
    college_id: Optional[UUID] = None,
    event_type: Optional[EventType] = None,
    limit: int = Query(10, ge=1, le=50),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Generate event popularity report (sorted by registrations)."""
    query = db.query(
        Event.id.label('event_id'),
        Event.title.label('event_title'),
        Event.event_type,
        func.count(Registration.id).label('total_registrations'),
        func.count(Attendance.id).label('total_attendance'),
        func.avg(Feedback.rating).label('average_rating')
    ).select_from(Event)\
     .outerjoin(Registration, and_(
         Event.id == Registration.event_id,
         Registration.status == RegistrationStatus.registered
     ))\
     .outerjoin(Attendance, Registration.id == Attendance.registration_id)\
     .outerjoin(Feedback, Attendance.id == Feedback.attendance_id)\
     .group_by(Event.id, Event.title, Event.event_type)\
     .order_by(desc(func.count(Registration.id)))\
     .limit(limit)
    
    # Apply filters
    if college_id:
        query = query.filter(Event.college_id == college_id)
    if event_type:
        query = query.filter(Event.event_type == event_type)
    
    results = query.all()
    
    data = []
    for rank, row in enumerate(results, 1):
        attendance_rate = 0.0
        if row.total_registrations > 0:
            attendance_rate = (row.total_attendance / row.total_registrations) * 100
        
        data.append({
            "rank": rank,
            "event_id": row.event_id,
            "event_title": row.event_title,
            "event_type": row.event_type,
            "total_registrations": row.total_registrations,
            "attendance_rate": round(attendance_rate, 2),
            "average_rating": round(float(row.average_rating), 2) if row.average_rating else None
        })
    
    return {
        "report_type": "event_popularity",
        "generated_at": datetime.utcnow(),
        "data": data,
        "total": len(data)
    }

@router.get("/student-participation")
def get_student_participation_report(
    college_id: Optional[UUID] = None,
    student_id: Optional[UUID] = None,
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Generate student participation report."""
    query = db.query(
        Student.id.label('student_id'),
        func.concat(Student.first_name, ' ', Student.last_name).label('student_name'),
        College.name.label('college_name'),
        func.count(Registration.id).label('total_registrations'),
        func.count(Attendance.id).label('total_attendance')
    ).select_from(Student)\
     .join(College, Student.college_id == College.id)\
     .outerjoin(Registration, and_(
         Student.id == Registration.student_id,
         Registration.status == RegistrationStatus.registered
     ))\
     .outerjoin(Attendance, Registration.id == Attendance.registration_id)\
     .group_by(Student.id, Student.first_name, Student.last_name, College.name)\
     .order_by(desc(func.count(Attendance.id)))\
     .limit(limit)
    
    # Apply filters
    if college_id:
        query = query.filter(Student.college_id == college_id)
    if student_id:
        query = query.filter(Student.id == student_id)
    
    results = query.all()
    
    data = []
    for row in results:
        attendance_rate = 0.0
        if row.total_registrations > 0:
            attendance_rate = (row.total_attendance / row.total_registrations) * 100
        
        # Get events attended
        events_query = db.query(
            Event.title.label('event_title'),
            Event.event_type,
            func.date(Attendance.check_in_time).label('attendance_date')
        ).select_from(Attendance)\
         .join(Registration, Attendance.registration_id == Registration.id)\
         .join(Event, Registration.event_id == Event.id)\
         .filter(Registration.student_id == row.student_id)
        
        events_attended = []
        for event_row in events_query.all():
            events_attended.append({
                "event_title": event_row.event_title,
                "event_type": event_row.event_type,
                "attendance_date": event_row.attendance_date.isoformat()
            })
        
        data.append({
            "student_id": row.student_id,
            "student_name": row.student_name,
            "college_name": row.college_name,
            "total_registrations": row.total_registrations,
            "total_attendance": row.total_attendance,
            "attendance_rate": round(attendance_rate, 2),
            "events_attended": events_attended
        })
    
    return {
        "report_type": "student_participation",
        "generated_at": datetime.utcnow(),
        "data": data,
        "total": len(data)
    }

@router.get("/top-active-students")
def get_top_active_students_report(
    college_id: Optional[UUID] = None,
    limit: int = Query(3, ge=1, le=10),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_active_user)
):
    """Generate top 3 active students report."""
    query = db.query(
        Student.id.label('student_id'),
        func.concat(Student.first_name, ' ', Student.last_name).label('student_name'),
        College.name.label('college_name'),
        func.count(Attendance.id).label('events_attended'),
        func.avg(Feedback.rating).label('average_rating_given')
    ).select_from(Student)\
     .join(College, Student.college_id == College.id)\
     .join(Registration, Student.id == Registration.student_id)\
     .join(Attendance, Registration.id == Attendance.registration_id)\
     .outerjoin(Feedback, Attendance.id == Feedback.attendance_id)\
     .group_by(Student.id, Student.first_name, Student.last_name, College.name)\
     .order_by(desc(func.count(Attendance.id)))\
     .limit(limit)
    
    # Apply filters
    if college_id:
        query = query.filter(Student.college_id == college_id)
    
    results = query.all()
    
    data = []
    for rank, row in enumerate(results, 1):
        data.append({
            "rank": rank,
            "student_id": row.student_id,
            "student_name": row.student_name,
            "college_name": row.college_name,
            "events_attended": row.events_attended,
            "average_rating_given": round(float(row.average_rating_given), 2) if row.average_rating_given else None
        })
    
    return {
        "report_type": "top_active_students",
        "generated_at": datetime.utcnow(),
        "data": data,
        "total": len(data)
    }
