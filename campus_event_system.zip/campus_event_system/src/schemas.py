from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID
from .models import EventType, UserRole, RegistrationStatus

# Base schemas
class CollegeBase(BaseModel):
    name: str
    code: str
    address: Optional[str] = None
    contact_email: Optional[EmailStr] = None
    contact_phone: Optional[str] = None

class CollegeCreate(CollegeBase):
    pass

class College(CollegeBase):
    id: UUID
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# Event schemas
class EventBase(BaseModel):
    title: str
    description: Optional[str] = None
    event_type: EventType
    start_time: datetime
    end_time: datetime
    venue: Optional[str] = None
    max_capacity: Optional[int] = None

class EventCreate(EventBase):
    pass

class EventUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    event_type: Optional[EventType] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    venue: Optional[str] = None
    max_capacity: Optional[int] = None
    is_active: Optional[bool] = None

class Event(EventBase):
    id: UUID
    college_id: UUID
    is_active: bool
    created_at: datetime
    updated_at: datetime
    college: College

    class Config:
        from_attributes = True

# Student schemas
class StudentBase(BaseModel):
    student_id: str
    first_name: str
    last_name: str
    email: EmailStr
    phone: Optional[str] = None
    department: Optional[str] = None
    year: Optional[int] = Field(None, ge=1, le=6)

class StudentCreate(StudentBase):
    college_id: UUID

class Student(StudentBase):
    id: UUID
    college_id: UUID
    created_at: datetime
    updated_at: datetime
    college: College

    class Config:
        from_attributes = True

# User schemas
class UserBase(BaseModel):
    username: str
    email: EmailStr
    role: UserRole

class UserCreate(UserBase):
    password: str
    college_id: UUID

class User(UserBase):
    id: UUID
    college_id: UUID
    is_active: bool
    created_at: datetime
    updated_at: datetime
    college: College

    class Config:
        from_attributes = True

# Registration schemas
class RegistrationBase(BaseModel):
    event_id: UUID
    student_id: UUID

class RegistrationCreate(RegistrationBase):
    pass

class Registration(RegistrationBase):
    id: UUID
    registration_time: datetime
    status: RegistrationStatus
    created_at: datetime
    event: Event
    student: Student

    class Config:
        from_attributes = True

# Attendance schemas
class AttendanceBase(BaseModel):
    check_in_time: datetime
    check_out_time: Optional[datetime] = None
    notes: Optional[str] = None

class AttendanceCreate(AttendanceBase):
    registration_id: UUID

class AttendanceUpdate(BaseModel):
    check_out_time: Optional[datetime] = None
    notes: Optional[str] = None

class Attendance(AttendanceBase):
    id: UUID
    registration_id: UUID
    created_at: datetime
    registration: Registration

    class Config:
        from_attributes = True

# Feedback schemas
class FeedbackBase(BaseModel):
    rating: int = Field(..., ge=1, le=5)
    comments: Optional[str] = None
    feedback_data: Optional[Dict[str, Any]] = None

class FeedbackCreate(FeedbackBase):
    attendance_id: UUID

class Feedback(FeedbackBase):
    id: UUID
    attendance_id: UUID
    created_at: datetime
    attendance: Attendance

    class Config:
        from_attributes = True

# Authentication schemas
class Token(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    user: User

class TokenData(BaseModel):
    username: Optional[str] = None

class UserLogin(BaseModel):
    username: str
    password: str

# Report schemas
class RegistrationReport(BaseModel):
    event_id: UUID
    event_title: str
    event_type: EventType
    college_name: str
    total_registrations: int
    active_registrations: int
    cancelled_registrations: int
    capacity_utilization: float

class AttendanceReport(BaseModel):
    event_id: UUID
    event_title: str
    total_registrations: int
    total_attendance: int
    attendance_percentage: float

class FeedbackReport(BaseModel):
    event_id: UUID
    event_title: str
    total_feedback: int
    average_rating: float
    rating_distribution: Dict[str, int]

class EventPopularityReport(BaseModel):
    rank: int
    event_id: UUID
    event_title: str
    event_type: EventType
    total_registrations: int
    attendance_rate: float
    average_rating: Optional[float] = None

class StudentParticipationReport(BaseModel):
    student_id: UUID
    student_name: str
    college_name: str
    total_registrations: int
    total_attendance: int
    attendance_rate: float
    events_attended: List[Dict[str, Any]]

class TopStudentReport(BaseModel):
    rank: int
    student_id: UUID
    student_name: str
    college_name: str
    events_attended: int
    average_rating_given: Optional[float] = None

# Generic response schemas
class ReportResponse(BaseModel):
    report_type: str
    generated_at: datetime
    data: List[Any]
    total: Optional[int] = None
    filters: Optional[Dict[str, Any]] = None

class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    limit: int
    offset: int
    has_next: bool
    has_prev: bool
