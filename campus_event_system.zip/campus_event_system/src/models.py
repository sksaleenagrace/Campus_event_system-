from sqlalchemy import Column, String, Text, Integer, Boolean, DateTime, Enum, ForeignKey, CheckConstraint, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum
from .database import Base

# Enums
class EventType(str, enum.Enum):
    workshop = "workshop"
    seminar = "seminar"
    hackathon = "hackathon"
    fest = "fest"
    other = "other"

class UserRole(str, enum.Enum):
    admin = "admin"
    staff = "staff"

class RegistrationStatus(str, enum.Enum):
    registered = "registered"
    cancelled = "cancelled"
    waitlisted = "waitlisted"

# Models
class College(Base):
    __tablename__ = "colleges"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    code = Column(String(10), unique=True, nullable=False)
    address = Column(Text)
    contact_email = Column(String(255))
    contact_phone = Column(String(20))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    events = relationship("Event", back_populates="college")
    students = relationship("Student", back_populates="college")
    users = relationship("User", back_populates="college")

class Event(Base):
    __tablename__ = "events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    college_id = Column(UUID(as_uuid=True), ForeignKey("colleges.id"), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    event_type = Column(Enum(EventType), nullable=False)
    start_time = Column(DateTime(timezone=True), nullable=False)
    end_time = Column(DateTime(timezone=True), nullable=False)
    venue = Column(String(255))
    max_capacity = Column(Integer)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    college = relationship("College", back_populates="events")
    registrations = relationship("Registration", back_populates="event")
    
    # Check constraint for valid time range
    __table_args__ = (
        CheckConstraint('end_time > start_time', name='valid_time_range'),
    )

class Student(Base):
    __tablename__ = "students"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    college_id = Column(UUID(as_uuid=True), ForeignKey("colleges.id"), nullable=False)
    student_id = Column(String(50), nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    phone = Column(String(20))
    department = Column(String(100))
    year = Column(Integer)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    college = relationship("College", back_populates="students")
    registrations = relationship("Registration", back_populates="student")

    # Unique constraint for student_id within college
    __table_args__ = (
        UniqueConstraint('college_id', 'student_id', name='unique_student_per_college'),
    )

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    college_id = Column(UUID(as_uuid=True), ForeignKey("colleges.id"), nullable=False)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    college = relationship("College", back_populates="users")

class Registration(Base):
    __tablename__ = "registrations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id = Column(UUID(as_uuid=True), ForeignKey("events.id"), nullable=False)
    student_id = Column(UUID(as_uuid=True), ForeignKey("students.id"), nullable=False)
    registration_time = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(Enum(RegistrationStatus), default=RegistrationStatus.registered)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    event = relationship("Event", back_populates="registrations")
    student = relationship("Student", back_populates="registrations")
    attendance = relationship("Attendance", back_populates="registration", uselist=False)

    # Unique constraint to prevent duplicate registrations
    __table_args__ = (
        UniqueConstraint('event_id', 'student_id', name='unique_registration'),
    )

class Attendance(Base):
    __tablename__ = "attendance"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    registration_id = Column(UUID(as_uuid=True), ForeignKey("registrations.id"), nullable=False)
    check_in_time = Column(DateTime(timezone=True), nullable=False)
    check_out_time = Column(DateTime(timezone=True))
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    registration = relationship("Registration", back_populates="attendance")
    feedback = relationship("Feedback", back_populates="attendance", uselist=False)

class Feedback(Base):
    __tablename__ = "feedback"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    attendance_id = Column(UUID(as_uuid=True), ForeignKey("attendance.id"), nullable=False)
    rating = Column(Integer, nullable=False)
    comments = Column(Text)
    feedback_data = Column(JSONB)  # For structured feedback forms
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    attendance = relationship("Attendance", back_populates="feedback")

    # Check constraint for valid rating
    __table_args__ = (
        CheckConstraint('rating >= 1 AND rating <= 5', name='valid_rating'),
    )
