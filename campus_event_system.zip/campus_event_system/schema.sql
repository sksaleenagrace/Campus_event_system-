-- Campus Event System Database Schema
-- PostgreSQL Database Schema

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create ENUM types
CREATE TYPE event_type_enum AS ENUM ('workshop', 'seminar', 'hackathon', 'fest', 'other');
CREATE TYPE user_role_enum AS ENUM ('admin', 'staff');
CREATE TYPE registration_status_enum AS ENUM ('registered', 'cancelled', 'waitlisted');

-- Colleges table
CREATE TABLE colleges (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    code VARCHAR(10) UNIQUE NOT NULL,
    address TEXT,
    contact_email VARCHAR(255),
    contact_phone VARCHAR(20),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Events table
CREATE TABLE events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    college_id UUID NOT NULL REFERENCES colleges(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    event_type event_type_enum NOT NULL,
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE NOT NULL,
    venue VARCHAR(255),
    max_capacity INTEGER,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT valid_time_range CHECK (end_time > start_time)
);

-- Students table
CREATE TABLE students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    college_id UUID NOT NULL REFERENCES colleges(id) ON DELETE CASCADE,
    student_id VARCHAR(50) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    department VARCHAR(100),
    year INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT unique_student_per_college UNIQUE (college_id, student_id)
);

-- Users table (for admin/staff authentication)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    college_id UUID NOT NULL REFERENCES colleges(id) ON DELETE CASCADE,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role user_role_enum NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Registrations table
CREATE TABLE registrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    registration_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    status registration_status_enum DEFAULT 'registered',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT unique_registration UNIQUE (event_id, student_id)
);

-- Attendance table
CREATE TABLE attendance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    registration_id UUID NOT NULL REFERENCES registrations(id) ON DELETE CASCADE,
    check_in_time TIMESTAMP WITH TIME ZONE NOT NULL,
    check_out_time TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Feedback table
CREATE TABLE feedback (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    attendance_id UUID NOT NULL REFERENCES attendance(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL,
    comments TEXT,
    feedback_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT valid_rating CHECK (rating >= 1 AND rating <= 5)
);

-- Create indexes for better performance
CREATE INDEX idx_events_college_id ON events(college_id);
CREATE INDEX idx_events_start_time ON events(start_time);
CREATE INDEX idx_events_event_type ON events(event_type);
CREATE INDEX idx_events_is_active ON events(is_active);

CREATE INDEX idx_students_college_id ON students(college_id);
CREATE INDEX idx_students_email ON students(email);
CREATE INDEX idx_students_department ON students(department);

CREATE INDEX idx_registrations_event_id ON registrations(event_id);
CREATE INDEX idx_registrations_student_id ON registrations(student_id);
CREATE INDEX idx_registrations_status ON registrations(status);

CREATE INDEX idx_attendance_registration_id ON attendance(registration_id);
CREATE INDEX idx_attendance_check_in_time ON attendance(check_in_time);

CREATE INDEX idx_feedback_attendance_id ON feedback(attendance_id);
CREATE INDEX idx_feedback_rating ON feedback(rating);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at columns
CREATE TRIGGER update_colleges_updated_at BEFORE UPDATE ON colleges
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_events_updated_at BEFORE UPDATE ON events
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_students_updated_at BEFORE UPDATE ON students
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Sample data insertion (for testing purposes)
-- Insert sample colleges
INSERT INTO colleges (id, name, code, address, contact_email, contact_phone) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'Tech University', 'TU', '123 Tech Street, Silicon Valley', 'admin@techuni.edu', '+1-555-0101'),
('550e8400-e29b-41d4-a716-446655440002', 'Engineering College', 'EC', '456 Engineering Ave, Tech City', 'info@engcollege.edu', '+1-555-0102'),
('550e8400-e29b-41d4-a716-446655440003', 'Science Institute', 'SI', '789 Science Blvd, Research Park', 'contact@sciinst.edu', '+1-555-0103');

-- Insert sample users (password is 'password123' hashed with bcrypt)
INSERT INTO users (id, college_id, username, email, password_hash, role) VALUES
('550e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440001', 'admin_tu', 'admin@techuni.edu', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj2JzZzQSJzS', 'admin'),
('550e8400-e29b-41d4-a716-446655440011', '550e8400-e29b-41d4-a716-446655440002', 'admin_ec', 'admin@engcollege.edu', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj2JzZzQSJzS', 'admin'),
('550e8400-e29b-41d4-a716-446655440012', '550e8400-e29b-41d4-a716-446655440003', 'admin_si', 'admin@sciinst.edu', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj2JzZzQSJzS', 'admin');

-- Insert sample students
INSERT INTO students (id, college_id, student_id, first_name, last_name, email, phone, department, year) VALUES
('550e8400-e29b-41d4-a716-446655440020', '550e8400-e29b-41d4-a716-446655440001', 'TU2024001', 'John', 'Doe', 'john.doe@student.techuni.edu', '+1-555-1001', 'Computer Science', 3),
('550e8400-e29b-41d4-a716-446655440021', '550e8400-e29b-41d4-a716-446655440001', 'TU2024002', 'Jane', 'Smith', 'jane.smith@student.techuni.edu', '+1-555-1002', 'Computer Science', 2),
('550e8400-e29b-41d4-a716-446655440022', '550e8400-e29b-41d4-a716-446655440001', 'TU2024003', 'Mike', 'Johnson', 'mike.johnson@student.techuni.edu', '+1-555-1003', 'Data Science', 4),
('550e8400-e29b-41d4-a716-446655440023', '550e8400-e29b-41d4-a716-446655440002', 'EC2024001', 'Sarah', 'Wilson', 'sarah.wilson@student.engcollege.edu', '+1-555-2001', 'Mechanical Engineering', 3),
('550e8400-e29b-41d4-a716-446655440024', '550e8400-e29b-41d4-a716-446655440002', 'EC2024002', 'David', 'Brown', 'david.brown@student.engcollege.edu', '+1-555-2002', 'Electrical Engineering', 2),
('550e8400-e29b-41d4-a716-446655440025', '550e8400-e29b-41d4-a716-446655440003', 'SI2024001', 'Emily', 'Davis', 'emily.davis@student.sciinst.edu', '+1-555-3001', 'Physics', 1);

-- Insert sample events
INSERT INTO events (id, college_id, title, description, event_type, start_time, end_time, venue, max_capacity) VALUES
('550e8400-e29b-41d4-a716-446655440030', '550e8400-e29b-41d4-a716-446655440001', 'AI/ML Workshop', 'Hands-on workshop on machine learning basics', 'workshop', '2024-03-15 10:00:00+00', '2024-03-15 16:00:00+00', 'Computer Lab 1', 50),
('550e8400-e29b-41d4-a716-446655440031', '550e8400-e29b-41d4-a716-446655440001', 'Tech Fest 2024', 'Annual technology festival with competitions', 'fest', '2024-03-20 09:00:00+00', '2024-03-22 18:00:00+00', 'Main Auditorium', 500),
('550e8400-e29b-41d4-a716-446655440032', '550e8400-e29b-41d4-a716-446655440002', 'Robotics Seminar', 'Latest trends in robotics and automation', 'seminar', '2024-03-18 14:00:00+00', '2024-03-18 17:00:00+00', 'Seminar Hall A', 100),
('550e8400-e29b-41d4-a716-446655440033', '550e8400-e29b-41d4-a716-446655440003', 'Quantum Computing Hackathon', '48-hour hackathon on quantum algorithms', 'hackathon', '2024-03-25 18:00:00+00', '2024-03-27 18:00:00+00', 'Innovation Lab', 30);

-- Insert sample registrations
INSERT INTO registrations (id, event_id, student_id, registration_time, status) VALUES
('550e8400-e29b-41d4-a716-446655440040', '550e8400-e29b-41d4-a716-446655440030', '550e8400-e29b-41d4-a716-446655440020', '2024-03-10 14:30:00+00', 'registered'),
('550e8400-e29b-41d4-a716-446655440041', '550e8400-e29b-41d4-a716-446655440030', '550e8400-e29b-41d4-a716-446655440021', '2024-03-10 15:00:00+00', 'registered'),
('550e8400-e29b-41d4-a716-446655440042', '550e8400-e29b-41d4-a716-446655440031', '550e8400-e29b-41d4-a716-446655440020', '2024-03-12 10:00:00+00', 'registered'),
('550e8400-e29b-41d4-a716-446655440043', '550e8400-e29b-41d4-a716-446655440032', '550e8400-e29b-41d4-a716-446655440023', '2024-03-15 09:00:00+00', 'registered'),
('550e8400-e29b-41d4-a716-446655440044', '550e8400-e29b-41d4-a716-446655440033', '550e8400-e29b-41d4-a716-446655440025', '2024-03-20 16:00:00+00', 'registered');

-- Insert sample attendance
INSERT INTO attendance (id, registration_id, check_in_time, check_out_time, notes) VALUES
('550e8400-e29b-41d4-a716-446655440050', '550e8400-e29b-41d4-a716-446655440040', '2024-03-15 10:05:00+00', '2024-03-15 15:45:00+00', 'Attended full workshop'),
('550e8400-e29b-41d4-a716-446655440051', '550e8400-e29b-41d4-a716-446655440041', '2024-03-15 10:15:00+00', '2024-03-15 15:30:00+00', 'Active participant'),
('550e8400-e29b-41d4-a716-446655440052', '550e8400-e29b-41d4-a716-446655440043', '2024-03-18 14:10:00+00', '2024-03-18 16:50:00+00', 'Asked good questions');

-- Insert sample feedback
INSERT INTO feedback (id, attendance_id, rating, comments, feedback_data) VALUES
('550e8400-e29b-41d4-a716-446655440060', '550e8400-e29b-41d4-a716-446655440050', 4, 'Great workshop! Learned a lot about ML algorithms.', '{"content_quality": 5, "instructor_rating": 4, "venue_rating": 3, "would_recommend": true}'),
('550e8400-e29b-41d4-a716-446655440061', '550e8400-e29b-41d4-a716-446655440051', 5, 'Excellent hands-on experience. Well organized.', '{"content_quality": 5, "instructor_rating": 5, "venue_rating": 4, "would_recommend": true}'),
('550e8400-e29b-41d4-a716-446655440062', '550e8400-e29b-41d4-a716-446655440052', 3, 'Good content but could be more interactive.', '{"content_quality": 4, "instructor_rating": 3, "venue_rating": 4, "would_recommend": true}');

-- Create views for common reporting queries
CREATE VIEW event_summary AS
SELECT 
    e.id,
    e.title,
    e.event_type,
    c.name as college_name,
    e.start_time,
    e.end_time,
    e.max_capacity,
    COUNT(DISTINCT r.id) as total_registrations,
    COUNT(DISTINCT CASE WHEN r.status = 'registered' THEN r.id END) as active_registrations,
    COUNT(DISTINCT a.id) as total_attendance,
    ROUND(AVG(f.rating), 2) as average_rating
FROM events e
JOIN colleges c ON e.college_id = c.id
LEFT JOIN registrations r ON e.id = r.event_id
LEFT JOIN attendance a ON r.id = a.registration_id
LEFT JOIN feedback f ON a.id = f.attendance_id
WHERE e.is_active = true
GROUP BY e.id, e.title, e.event_type, c.name, e.start_time, e.end_time, e.max_capacity;

CREATE VIEW student_activity AS
SELECT 
    s.id,
    s.first_name || ' ' || s.last_name as full_name,
    s.email,
    c.name as college_name,
    s.department,
    s.year,
    COUNT(DISTINCT r.id) as total_registrations,
    COUNT(DISTINCT a.id) as events_attended,
    ROUND(AVG(f.rating), 2) as average_rating_given
FROM students s
JOIN colleges c ON s.college_id = c.id
LEFT JOIN registrations r ON s.id = r.student_id AND r.status = 'registered'
LEFT JOIN attendance a ON r.id = a.registration_id
LEFT JOIN feedback f ON a.id = f.attendance_id
GROUP BY s.id, s.first_name, s.last_name, s.email, c.name, s.department, s.year;
