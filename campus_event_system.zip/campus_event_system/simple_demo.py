#!/usr/bin/env python3
"""
Simple Campus Event System Demo Server
"""

import http.server
import socketserver
import webbrowser
import threading
import time
import json
import sqlite3
import uuid
from datetime import datetime
from urllib.parse import urlparse, parse_qs

# Database setup
DB_FILE = "campus_events.db"

def init_database():
    """Initialize SQLite database with sample data"""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    # Create tables
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS colleges (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            code TEXT UNIQUE NOT NULL,
            address TEXT,
            contact_email TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id TEXT PRIMARY KEY,
            college_id TEXT,
            student_id TEXT NOT NULL,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            department TEXT,
            year INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (college_id) REFERENCES colleges (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS events (
            id TEXT PRIMARY KEY,
            college_id TEXT,
            title TEXT NOT NULL,
            description TEXT,
            event_type TEXT NOT NULL,
            start_time TIMESTAMP,
            end_time TIMESTAMP,
            venue TEXT,
            max_capacity INTEGER,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (college_id) REFERENCES colleges (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS registrations (
            id TEXT PRIMARY KEY,
            event_id TEXT,
            student_id TEXT,
            registration_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'registered',
            FOREIGN KEY (event_id) REFERENCES events (id),
            FOREIGN KEY (student_id) REFERENCES students (id)
        )
    ''')
    
    # Check if data exists
    cursor.execute("SELECT COUNT(*) FROM colleges")
    if cursor.fetchone()[0] == 0:
        # Insert sample data
        colleges = [
            (str(uuid.uuid4()), "Tech University", "TU", "123 Tech Street", "admin@techuni.edu"),
            (str(uuid.uuid4()), "Engineering College", "EC", "456 Engineering Ave", "info@engcollege.edu"),
            (str(uuid.uuid4()), "Science Institute", "SI", "789 Science Blvd", "contact@sciinst.edu")
        ]
        
        cursor.executemany(
            "INSERT INTO colleges (id, name, code, address, contact_email) VALUES (?, ?, ?, ?, ?)",
            colleges
        )
        
        # Get college IDs
        cursor.execute("SELECT id, code FROM colleges")
        college_map = {code: id for id, code in cursor.fetchall()}
        
        # Insert students
        students = [
            (str(uuid.uuid4()), college_map["TU"], "TU2024001", "John", "Doe", "john.doe@techuni.edu", "123-456-7890", "Computer Science", 3),
            (str(uuid.uuid4()), college_map["TU"], "TU2024002", "Jane", "Smith", "jane.smith@techuni.edu", "123-456-7891", "Data Science", 2),
            (str(uuid.uuid4()), college_map["EC"], "EC2024001", "Mike", "Johnson", "mike.johnson@engcollege.edu", "123-456-7892", "Mechanical Engineering", 4),
            (str(uuid.uuid4()), college_map["SI"], "SI2024001", "Sarah", "Wilson", "sarah.wilson@sciinst.edu", "123-456-7893", "Physics", 1)
        ]
        
        cursor.executemany(
            "INSERT INTO students (id, college_id, student_id, first_name, last_name, email, phone, department, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            students
        )
        
        # Insert events
        events = [
            (str(uuid.uuid4()), college_map["TU"], "AI/ML Workshop", "Hands-on machine learning workshop", "workshop", "2024-04-15 10:00:00", "2024-04-15 16:00:00", "Computer Lab 1", 50),
            (str(uuid.uuid4()), college_map["TU"], "Tech Fest 2024", "Annual technology festival", "fest", "2024-04-20 09:00:00", "2024-04-22 18:00:00", "Main Auditorium", 500),
            (str(uuid.uuid4()), college_map["EC"], "Robotics Seminar", "Latest trends in robotics", "seminar", "2024-04-18 14:00:00", "2024-04-18 17:00:00", "Seminar Hall A", 100)
        ]
        
        cursor.executemany(
            "INSERT INTO events (id, college_id, title, description, event_type, start_time, end_time, venue, max_capacity) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            events
        )
        
        # Insert sample registrations
        cursor.execute("SELECT id FROM students LIMIT 3")
        student_ids = [row[0] for row in cursor.fetchall()]
        cursor.execute("SELECT id FROM events LIMIT 2")
        event_ids = [row[0] for row in cursor.fetchall()]
        
        registrations = [
            (str(uuid.uuid4()), event_ids[0], student_ids[0]),
            (str(uuid.uuid4()), event_ids[0], student_ids[1]),
            (str(uuid.uuid4()), event_ids[1], student_ids[0])
        ]
        
        cursor.executemany(
            "INSERT INTO registrations (id, event_id, student_id) VALUES (?, ?, ?)",
            registrations
        )
    
    conn.commit()
    conn.close()
    print("✅ Database initialized with sample data")

class CampusEventHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        if path == "/":
            self.send_dashboard()
        elif path == "/api/colleges":
            self.send_colleges()
        elif path == "/api/students":
            self.send_students()
        elif path == "/api/events":
            self.send_events()
        elif path == "/api/registrations":
            self.send_registrations()
        elif path == "/api/stats":
            self.send_stats()
        else:
            super().do_GET()
    
    def do_POST(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')
        
        try:
            data = json.loads(post_data) if post_data else {}
        except:
            data = {}
        
        if path == "/api/students":
            self.create_student(data)
        elif path == "/api/events":
            self.create_event(data)
        elif path == "/api/registrations":
            self.create_registration(data)
        else:
            self.send_error(404, "Not Found")
    
    def send_json_response(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode())
    
    def send_colleges(self):
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, code, address, contact_email FROM colleges")
        colleges = [{"id": row[0], "name": row[1], "code": row[2], "address": row[3], "contact_email": row[4]} for row in cursor.fetchall()]
        conn.close()
        self.send_json_response(colleges)
    
    def send_students(self):
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.id, s.student_id, s.first_name, s.last_name, s.email, s.department, s.year, c.name
            FROM students s JOIN colleges c ON s.college_id = c.id
        """)
        students = [{
            "id": row[0], "student_id": row[1], "first_name": row[2], "last_name": row[3],
            "email": row[4], "department": row[5], "year": row[6], "college_name": row[7]
        } for row in cursor.fetchall()]
        conn.close()
        self.send_json_response(students)
    
    def send_events(self):
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT e.id, e.title, e.description, e.event_type, e.start_time, e.end_time, e.venue, e.max_capacity, c.name,
                   (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.id) as reg_count
            FROM events e JOIN colleges c ON e.college_id = c.id
        """)
        events = [{
            "id": row[0], "title": row[1], "description": row[2], "event_type": row[3],
            "start_time": row[4], "end_time": row[5], "venue": row[6], "max_capacity": row[7],
            "college_name": row[8], "registrations_count": row[9]
        } for row in cursor.fetchall()]
        conn.close()
        self.send_json_response(events)
    
    def send_registrations(self):
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT r.id, e.title, s.first_name || ' ' || s.last_name, s.email, r.registration_time, r.status
            FROM registrations r 
            JOIN events e ON r.event_id = e.id 
            JOIN students s ON r.student_id = s.id
        """)
        registrations = [{
            "id": row[0], "event_title": row[1], "student_name": row[2],
            "student_email": row[3], "registration_time": row[4], "status": row[5]
        } for row in cursor.fetchall()]
        conn.close()
        self.send_json_response(registrations)
    
    def send_stats(self):
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM colleges")
        total_colleges = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM students")
        total_students = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM events")
        total_events = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM registrations")
        total_registrations = cursor.fetchone()[0]
        
        conn.close()
        
        stats = {
            "total_colleges": total_colleges,
            "total_students": total_students,
            "total_events": total_events,
            "total_registrations": total_registrations,
            "timestamp": datetime.now().isoformat()
        }
        self.send_json_response(stats)
    
    def create_student(self, data):
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        # Get first college ID for demo
        cursor.execute("SELECT id FROM colleges LIMIT 1")
        college_id = cursor.fetchone()[0]
        
        student_id = str(uuid.uuid4())
        try:
            cursor.execute("""
                INSERT INTO students (id, college_id, student_id, first_name, last_name, email, department, year)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                student_id, college_id, data.get('student_id', f'STU{datetime.now().strftime("%Y%m%d%H%M%S")}'),
                data.get('first_name', ''), data.get('last_name', ''), data.get('email', ''),
                data.get('department', ''), data.get('year', 1)
            ))
            conn.commit()
            self.send_json_response({"id": student_id, "message": "Student created successfully"})
        except Exception as e:
            self.send_json_response({"error": str(e)}, 400)
        finally:
            conn.close()
    
    def create_event(self, data):
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        # Get first college ID for demo
        cursor.execute("SELECT id FROM colleges LIMIT 1")
        college_id = cursor.fetchone()[0]
        
        event_id = str(uuid.uuid4())
        try:
            cursor.execute("""
                INSERT INTO events (id, college_id, title, description, event_type, venue, max_capacity, start_time, end_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                event_id, college_id, data.get('title', ''), data.get('description', ''),
                data.get('event_type', 'workshop'), data.get('venue', ''), data.get('max_capacity', 50),
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))
            conn.commit()
            self.send_json_response({"id": event_id, "message": "Event created successfully"})
        except Exception as e:
            self.send_json_response({"error": str(e)}, 400)
        finally:
            conn.close()
    
    def create_registration(self, data):
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        registration_id = str(uuid.uuid4())
        try:
            cursor.execute("""
                INSERT INTO registrations (id, event_id, student_id)
                VALUES (?, ?, ?)
            """, (registration_id, data.get('event_id', ''), data.get('student_id', '')))
            conn.commit()
            self.send_json_response({"id": registration_id, "message": "Registration successful"})
        except Exception as e:
            self.send_json_response({"error": str(e)}, 400)
        finally:
            conn.close()
    
    def send_dashboard(self):
        html = '''<!DOCTYPE html>
<html>
<head>
    <title>Campus Event System - Live Database Demo</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }
        .stat-number { font-size: 2em; font-weight: bold; }
        .section { margin-bottom: 30px; }
        .section h3 { color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        .btn { background: #667eea; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin: 5px; }
        .btn:hover { background: #5a67d8; }
        .result { background: #f8f9fa; border: 1px solid #ddd; padding: 15px; border-radius: 5px; margin-top: 10px; font-family: monospace; white-space: pre-wrap; max-height: 400px; overflow-y: auto; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input, .form-group select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎓 Campus Event System - Live Database Demo</h1>
            <p><strong>Real SQLite Database Operations</strong> | Port: 8080</p>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-number" id="colleges">-</div>
                <div>Colleges</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="students">-</div>
                <div>Students</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="events">-</div>
                <div>Events</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="registrations">-</div>
                <div>Registrations</div>
            </div>
        </div>
        
        <div class="section">
            <h3>📊 Live Data Operations</h3>
            <button class="btn" onclick="loadData('colleges')">Load Colleges</button>
            <button class="btn" onclick="loadData('students')">Load Students</button>
            <button class="btn" onclick="loadData('events')">Load Events</button>
            <button class="btn" onclick="loadData('registrations')">Load Registrations</button>
            <button class="btn" onclick="refreshStats()">Refresh Stats</button>
            <div id="data-result" class="result" style="display:none;"></div>
        </div>
        
        <div class="section">
            <h3>➕ Add New Student</h3>
            <div class="form-group">
                <label>First Name:</label>
                <input type="text" id="firstName" placeholder="Enter first name">
            </div>
            <div class="form-group">
                <label>Last Name:</label>
                <input type="text" id="lastName" placeholder="Enter last name">
            </div>
            <div class="form-group">
                <label>Email:</label>
                <input type="email" id="email" placeholder="Enter email">
            </div>
            <div class="form-group">
                <label>Department:</label>
                <input type="text" id="department" placeholder="e.g., Computer Science">
            </div>
            <button class="btn" onclick="addStudent()">Add Student to Database</button>
            <div id="student-result" class="result" style="display:none;"></div>
        </div>
        
        <div class="section">
            <h3>🎉 Add New Event</h3>
            <div class="form-group">
                <label>Event Title:</label>
                <input type="text" id="eventTitle" placeholder="Enter event title">
            </div>
            <div class="form-group">
                <label>Event Type:</label>
                <select id="eventType">
                    <option value="workshop">Workshop</option>
                    <option value="seminar">Seminar</option>
                    <option value="hackathon">Hackathon</option>
                    <option value="fest">Fest</option>
                </select>
            </div>
            <div class="form-group">
                <label>Venue:</label>
                <input type="text" id="eventVenue" placeholder="Enter venue">
            </div>
            <button class="btn" onclick="addEvent()">Add Event to Database</button>
            <div id="event-result" class="result" style="display:none;"></div>
        </div>
    </div>
    
    <script>
        async function refreshStats() {
            try {
                const response = await fetch('/api/stats');
                const data = await response.json();
                document.getElementById('colleges').textContent = data.total_colleges;
                document.getElementById('students').textContent = data.total_students;
                document.getElementById('events').textContent = data.total_events;
                document.getElementById('registrations').textContent = data.total_registrations;
            } catch (error) {
                console.error('Error loading stats:', error);
            }
        }
        
        async function loadData(type) {
            try {
                const response = await fetch(`/api/${type}`);
                const data = await response.json();
                const resultDiv = document.getElementById('data-result');
                
                if (data.length === 0) {
                    resultDiv.innerHTML = `<p>No ${type} found.</p>`;
                } else {
                    let html = `<h4>${type.charAt(0).toUpperCase() + type.slice(1)} (${data.length} records)</h4>`;
                    html += '<table style="width:100%; border-collapse: collapse; margin-top: 10px;">';
                    
                    // Create header
                    html += '<thead><tr style="background: #f0f0f0;">';
                    Object.keys(data[0]).forEach(key => {
                        html += `<th style="padding: 10px; border: 1px solid #ddd; text-align: left;">${key.replace('_', ' ').toUpperCase()}</th>`;
                    });
                    html += '</tr></thead>';
                    
                    // Create rows
                    html += '<tbody>';
                    data.forEach((item, index) => {
                        html += `<tr style="background: ${index % 2 === 0 ? '#f9f9f9' : 'white'};">`;
                        Object.values(item).forEach(value => {
                            html += `<td style="padding: 10px; border: 1px solid #ddd;">${value || '-'}</td>`;
                        });
                        html += '</tr>';
                    });
                    html += '</tbody></table>';
                    
                    resultDiv.innerHTML = html;
                }
                
                resultDiv.style.display = 'block';
                resultDiv.className = 'result';
            } catch (error) {
                console.error('Error loading data:', error);
                document.getElementById('data-result').innerHTML = '<p style="color: red;">Error loading data. Please try again.</p>';
                document.getElementById('data-result').style.display = 'block';
            }
        }
        
        async function addStudent() {
            const studentData = {
                first_name: document.getElementById('firstName').value,
                last_name: document.getElementById('lastName').value,
                email: document.getElementById('email').value,
                department: document.getElementById('department').value,
                year: 2
            };
            
            try {
                const response = await fetch('/api/students', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(studentData)
                });
                const result = await response.json();
                const resultDiv = document.getElementById('student-result');
                resultDiv.textContent = JSON.stringify(result, null, 2);
                resultDiv.style.display = 'block';
                resultDiv.className = response.ok ? 'result success' : 'result error';
                if (response.ok) {
                    // Clear form
                    document.getElementById('firstName').value = '';
                    document.getElementById('lastName').value = '';
                    document.getElementById('email').value = '';
                    document.getElementById('department').value = '';
                    refreshStats();
                }
            } catch (error) {
                console.error('Error adding student:', error);
            }
        }
        
        async function addEvent() {
            const eventData = {
                title: document.getElementById('eventTitle').value,
                event_type: document.getElementById('eventType').value,
                venue: document.getElementById('eventVenue').value,
                max_capacity: 100
            };
            
            try {
                const response = await fetch('/api/events', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(eventData)
                });
                const result = await response.json();
                const resultDiv = document.getElementById('event-result');
                resultDiv.textContent = JSON.stringify(result, null, 2);
                resultDiv.style.display = 'block';
                resultDiv.className = response.ok ? 'result success' : 'result error';
                if (response.ok) {
                    // Clear form
                    document.getElementById('eventTitle').value = '';
                    document.getElementById('eventVenue').value = '';
                    refreshStats();
                }
            } catch (error) {
                console.error('Error adding event:', error);
            }
        }
        
        // Load stats on page load
        refreshStats();
        
        // Auto-refresh every 10 seconds
        setInterval(refreshStats, 10000);
    </script>
</body>
</html>'''
        
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(html.encode())

def start_server():
    try:
        init_database()
        PORT = 8080
        Handler = CampusEventHandler
        
        with socketserver.TCPServer(("", PORT), Handler) as httpd:
            print(f"🚀 Campus Event System Live Demo Server")
            print(f"📊 Dashboard: http://localhost:{PORT}")
            print(f"💾 Database: SQLite ({DB_FILE})")
            print(f"🔄 Real-time database operations enabled")
            print(f"📡 Server running on port {PORT}...")
            httpd.serve_forever()
    except Exception as e:
        print(f"❌ Server error: {e}")
        print("Trying alternative port...")
        try:
            PORT = 8081
            with socketserver.TCPServer(("", PORT), Handler) as httpd:
                print(f"🚀 Server started on alternative port {PORT}")
                print(f"📊 Dashboard: http://localhost:{PORT}")
                httpd.serve_forever()
        except Exception as e2:
            print(f"❌ Alternative port also failed: {e2}")

if __name__ == "__main__":
    print("🚀 Starting Campus Event System Server...")
    start_server()
