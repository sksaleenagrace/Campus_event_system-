import http.server
import socketserver
import webbrowser
import threading
import time

PORT = 8080

class SimpleHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            html = """
<!DOCTYPE html>
<html>
<head>
    <title>Campus Event System - Simple Demo</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f0f2f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 20px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; }
        .header h1 { color: #1a73e8; margin-bottom: 10px; }
        .status { background: #e8f5e8; border: 1px solid #4caf50; padding: 15px; border-radius: 8px; margin: 20px 0; }
        .section { margin: 30px 0; padding: 20px; background: #f8f9fa; border-radius: 8px; }
        .btn { background: #1a73e8; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; margin: 5px; font-size: 14px; }
        .btn:hover { background: #1557b0; }
        .feature { display: flex; align-items: center; margin: 15px 0; }
        .feature-icon { font-size: 24px; margin-right: 15px; }
        .code-block { background: #f1f3f4; border: 1px solid #dadce0; padding: 15px; border-radius: 6px; font-family: monospace; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎓 Campus Event System</h1>
            <p>Server is Running Successfully!</p>
        </div>
        
        <div class="status">
            <strong>✅ Server Status:</strong> Running on localhost:8080<br>
            <strong>🕒 Started:</strong> <span id="timestamp"></span>
        </div>
        
        <div class="section">
            <h3>🚀 Available Features</h3>
            <div class="feature">
                <span class="feature-icon">👥</span>
                <div>
                    <strong>Student Management</strong><br>
                    Register students, manage profiles, track participation
                </div>
            </div>
            <div class="feature">
                <span class="feature-icon">🎉</span>
                <div>
                    <strong>Event Management</strong><br>
                    Create events, manage registrations, track attendance
                </div>
            </div>
            <div class="feature">
                <span class="feature-icon">📊</span>
                <div>
                    <strong>Reporting System</strong><br>
                    Generate reports, view analytics, export data
                </div>
            </div>
            <div class="feature">
                <span class="feature-icon">🏫</span>
                <div>
                    <strong>Multi-College Support</strong><br>
                    Manage multiple colleges, departments, and campuses
                </div>
            </div>
        </div>
        
        <div class="section">
            <h3>📋 Sample Data</h3>
            <p>The system includes pre-loaded sample data:</p>
            <ul>
                <li><strong>3 Colleges:</strong> Tech University, Engineering College, Science Institute</li>
                <li><strong>4 Students:</strong> John Doe, Jane Smith, Mike Johnson, Sarah Wilson</li>
                <li><strong>3 Events:</strong> AI/ML Workshop, Tech Fest 2024, Robotics Seminar</li>
                <li><strong>Multiple Registrations:</strong> Students registered for various events</li>
            </ul>
        </div>
        
        <div class="section">
            <h3>🔗 Quick Actions</h3>
            <button class="btn" onclick="openStudentForm()">👤 Student Registration</button>
            <button class="btn" onclick="openEventDemo()">🎉 Event Demo</button>
            <button class="btn" onclick="openAPI()">🔌 API Documentation</button>
            <button class="btn" onclick="refreshPage()">🔄 Refresh</button>
        </div>
        
        <div class="section">
            <h3>💻 Technical Details</h3>
            <div class="code-block">
Server: Python HTTP Server<br>
Port: 8080<br>
Database: SQLite (campus_events.db)<br>
Framework: Custom HTTP handlers<br>
Status: Active and Responding
            </div>
        </div>
        
        <div class="section">
            <h3>📁 Project Structure</h3>
            <p>Complete Campus Event System with:</p>
            <ul>
                <li>FastAPI backend with SQLAlchemy ORM</li>
                <li>PostgreSQL/SQLite database support</li>
                <li>JWT authentication system</li>
                <li>Comprehensive API endpoints</li>
                <li>Reporting and analytics</li>
                <li>UI mockups and wireframes</li>
                <li>Postman collection for testing</li>
            </ul>
        </div>
    </div>
    
    <script>
        document.getElementById('timestamp').textContent = new Date().toLocaleString();
        
        function openStudentForm() {
            window.open('student_registration.html', '_blank');
        }
        
        function openEventDemo() {
            window.open('simple_demo.html', '_blank');
        }
        
        function openAPI() {
            alert('API Documentation available in the full FastAPI version. Check /docs endpoint when running the FastAPI server.');
        }
        
        function refreshPage() {
            location.reload();
        }
        
        // Auto-refresh timestamp every second
        setInterval(() => {
            document.getElementById('timestamp').textContent = new Date().toLocaleString();
        }, 1000);
    </script>
</body>
</html>
            """
            
            self.wfile.write(html.encode())
        else:
            super().do_GET()

def start_server():
    try:
        with socketserver.TCPServer(("", PORT), SimpleHandler) as httpd:
            print(f"✅ Server started successfully!")
            print(f"🌐 Open: http://localhost:{PORT}")
            print(f"🔄 Server running on port {PORT}...")
            httpd.serve_forever()
    except Exception as e:
        print(f"❌ Server error: {e}")

if __name__ == "__main__":
    print("🚀 Starting Campus Event System Server...")
    
    # Start server in a separate thread
    server_thread = threading.Thread(target=start_server)
    server_thread.daemon = True
    server_thread.start()
    
    # Wait a moment for server to start
    time.sleep(2)
    
    # Try to open browser
    try:
        webbrowser.open(f'http://localhost:{PORT}')
        print("🌐 Browser opened automatically")
    except:
        print("⚠️  Please open browser manually: http://localhost:8080")
    
    # Keep main thread alive
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 Server stopped")
