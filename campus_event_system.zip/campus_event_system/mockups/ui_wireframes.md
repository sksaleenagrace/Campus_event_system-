# Campus Event System - UI Mockups & Wireframes

## Admin Portal Wireframes

### 1. Dashboard Overview
```
┌─────────────────────────────────────────────────────────────────┐
│ Campus Event System - Admin Portal                              │
├─────────────────────────────────────────────────────────────────┤
│ [Logo] Dashboard | Events | Students | Reports | Settings      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ │
│ │   Total     │ │   Active    │ │   Total     │ │  Average    │ │
│ │   Events    │ │   Events    │ │ Students    │ │  Rating     │ │
│ │     24      │ │     18      │ │    1,247    │ │    4.2      │ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │                Recent Events                                │ │
│ │ ┌─────────────────────────────────────────────────────────┐ │ │
│ │ │ AI/ML Workshop        | Mar 15 | 45 reg | 38 att | 4.2★│ │ │
│ │ │ Tech Fest 2024        | Mar 20 | 368 reg| 295 att| 4.1★│ │ │
│ │ │ Robotics Seminar      | Mar 18 | 85 reg | 72 att | 3.9★│ │ │
│ │ └─────────────────────────────────────────────────────────┘ │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │                Quick Actions                                │ │
│ │ [+ Create Event] [📊 View Reports] [👥 Manage Students]    │ │
│ └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### 2. Event Management Page
```
┌─────────────────────────────────────────────────────────────────┐
│ Events Management                                    [+ New Event]│
├─────────────────────────────────────────────────────────────────┤
│ Filters: [All Types ▼] [Active ▼] [This Month ▼] [Search...]   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ AI/ML Workshop                                    [Edit][Del]│ │
│ │ Workshop • Mar 15, 2024 • Computer Lab 1                   │ │
│ │ 45 registered • 38 attended • 4.2★ rating                  │ │
│ │ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐           │ │
│ │ │View Regs│ │Attendance│ │Feedback │ │ Reports │           │ │
│ │ └─────────┘ └─────────┘ └─────────┘ └─────────┘           │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ Tech Fest 2024                                   [Edit][Del]│ │
│ │ Fest • Mar 20-22, 2024 • Main Auditorium                   │ │
│ │ 368 registered • 295 attended • 4.1★ rating                │ │
│ │ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐           │ │
│ │ │View Regs│ │Attendance│ │Feedback │ │ Reports │           │ │
│ │ └─────────┘ └─────────┘ └─────────┘ └─────────┘           │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                 │
│                        [Load More Events]                      │
└─────────────────────────────────────────────────────────────────┘
```

### 3. Create/Edit Event Form
```
┌─────────────────────────────────────────────────────────────────┐
│ Create New Event                                     [Save][Cancel]│
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ Event Title: [AI/ML Advanced Workshop                        ] │
│                                                                 │
│ Event Type:  [Workshop ▼]                                      │
│                                                                 │
│ Description: ┌─────────────────────────────────────────────────┐ │
│              │Advanced machine learning techniques and         │ │
│              │practical implementation using Python and        │ │
│              │popular ML libraries like scikit-learn          │ │
│              └─────────────────────────────────────────────────┘ │
│                                                                 │
│ Start Date:  [2024-04-15] Time: [10:00 AM]                    │
│ End Date:    [2024-04-15] Time: [04:00 PM]                    │
│                                                                 │
│ Venue:       [Computer Lab 2                                 ] │
│                                                                 │
│ Max Capacity:[50        ] (Leave blank for unlimited)          │
│                                                                 │
│ ☑ Event is Active                                              │
│                                                                 │
│                        [Save Event] [Cancel]                   │
└─────────────────────────────────────────────────────────────────┘
```

### 4. Reports Dashboard
```
┌─────────────────────────────────────────────────────────────────┐
│ Reports & Analytics                                              │
├─────────────────────────────────────────────────────────────────┤
│ Date Range: [Last 30 Days ▼] College: [All ▼] Type: [All ▼]   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │                    Quick Reports                            │ │
│ │ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐           │ │
│ │ │Event        │ │Attendance   │ │Student      │           │ │
│ │ │Popularity   │ │Rates        │ │Participation│           │ │
│ │ │[Generate]   │ │[Generate]   │ │[Generate]   │           │ │
│ │ └─────────────┘ └─────────────┘ └─────────────┘           │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │                 Attendance Trends                           │ │
│ │    %                                                        │ │
│ │ 100├─────────────────────────────────────────────────────   │ │
│ │  90├──────────●──────●──────────────●───────────────────   │ │
│ │  80├────●─────────────────●──────────────●───────────────   │ │
│ │  70├─────────────────────────────────────────────────────   │ │
│ │    └─────────────────────────────────────────────────────   │ │
│ │     Jan    Feb    Mar    Apr    May    Jun    Jul           │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │                 Top Performing Events                       │ │
│ │ 1. Tech Fest 2024        368 reg  80.2% att  4.1★         │ │
│ │ 2. AI/ML Workshop         45 reg   84.4% att  4.2★         │ │
│ │ 3. Robotics Seminar       85 reg   84.7% att  3.9★         │ │
│ └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

## Student Mobile App Wireframes

### 1. Event Browse Screen
```
┌─────────────────────────────────┐
│ ☰  Campus Events         🔔 👤 │
├─────────────────────────────────┤
│                                 │
│ 🔍 Search events...             │
│                                 │
│ [All] [Workshop] [Seminar] [+]  │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ 🤖 AI/ML Workshop           │ │
│ │ Mar 15 • 10:00 AM           │ │
│ │ Computer Lab 1 • 45/50      │ │
│ │ ⭐ 4.2 • 📍 Tech University │ │
│ │           [Register Now] ✓  │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ 🎉 Tech Fest 2024           │ │
│ │ Mar 20-22 • 9:00 AM         │ │
│ │ Main Auditorium • 368/500   │ │
│ │ ⭐ 4.1 • 📍 Tech University │ │
│ │           [Register Now]    │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ 🤖 Robotics Seminar         │ │
│ │ Mar 18 • 2:00 PM            │ │
│ │ Seminar Hall A • 85/100     │ │
│ │ ⭐ 3.9 • 📍 Eng College     │ │
│ │           [Register Now]    │ │
│ └─────────────────────────────┘ │
│                                 │
└─────────────────────────────────┘
│ [🏠] [📅] [🎫] [👤] [⚙️]      │
```

### 2. Event Details Screen
```
┌─────────────────────────────────┐
│ ← AI/ML Workshop            ⭐🔗│
├─────────────────────────────────┤
│                                 │
│ ┌─────────────────────────────┐ │
│ │     🤖 AI/ML Workshop       │ │
│ │                             │ │
│ │ 📅 March 15, 2024           │ │
│ │ 🕙 10:00 AM - 4:00 PM       │ │
│ │ 📍 Computer Lab 1           │ │
│ │ 🏫 Tech University          │ │
│ │ 👥 45/50 registered         │ │
│ │ ⭐ 4.2 rating (28 reviews)  │ │
│ └─────────────────────────────┘ │
│                                 │
│ About this Event                │
│ ┌─────────────────────────────┐ │
│ │ Hands-on workshop covering  │ │
│ │ machine learning fundamentals│ │
│ │ and practical applications  │ │
│ │ using Python and popular    │ │
│ │ ML libraries.               │ │
│ └─────────────────────────────┘ │
│                                 │
│ What to Bring                   │
│ • Laptop with Python installed │
│ • Notebook for taking notes    │
│ • Enthusiasm to learn!         │
│                                 │
│ ┌─────────────────────────────┐ │
│ │        [Register Now]       │ │
│ └─────────────────────────────┘ │
│                                 │
└─────────────────────────────────┘
│ [🏠] [📅] [🎫] [👤] [⚙️]      │
```

### 3. My Events Screen
```
┌─────────────────────────────────┐
│ My Events                    📊 │
├─────────────────────────────────┤
│                                 │
│ [Registered] [Attended] [Past]  │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ ✅ AI/ML Workshop           │ │
│ │ Mar 15 • Attended           │ │
│ │ Computer Lab 1              │ │
│ │ [📝 Give Feedback]          │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ 🎫 Tech Fest 2024           │ │
│ │ Mar 20-22 • Registered      │ │
│ │ Main Auditorium             │ │
│ │ [📱 Check In] [❌ Cancel]   │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │ ⏰ Robotics Seminar         │ │
│ │ Mar 18 • Upcoming           │ │
│ │ Seminar Hall A              │ │
│ │ [📱 Check In] [❌ Cancel]   │ │
│ └─────────────────────────────┘ │
│                                 │
│ Your Stats                      │
│ 📊 12 events attended           │
│ ⭐ 4.3 average rating given     │
│ 🏆 Top 10% most active         │
│                                 │
└─────────────────────────────────┘
│ [🏠] [📅] [🎫] [👤] [⚙️]      │
```

### 4. Check-in Screen
```
┌─────────────────────────────────┐
│ ← Check In                      │
├─────────────────────────────────┤
│                                 │
│        🎫 Event Check-in        │
│                                 │
│ ┌─────────────────────────────┐ │
│ │     AI/ML Workshop          │ │
│ │     March 15, 2024          │ │
│ │     10:00 AM - 4:00 PM      │ │
│ │     Computer Lab 1          │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │                             │ │
│ │    📱 Scan QR Code          │ │
│ │                             │ │
│ │  ┌─────────────────────┐    │ │
│ │  │ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ │    │ │
│ │  │ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ │    │ │
│ │  │ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ │    │ │
│ │  └─────────────────────┘    │ │
│ │                             │ │
│ │    or enter code manually   │ │
│ └─────────────────────────────┘ │
│                                 │
│ Event Code: [____________]      │
│                                 │
│ ┌─────────────────────────────┐ │
│ │         [Check In]          │ │
│ └─────────────────────────────┘ │
│                                 │
│ ┌─────────────────────────────┐ │
│ │      [Manual Check-in]      │ │
│ └─────────────────────────────┘ │
│                                 │
└─────────────────────────────────┘
```

### 5. Feedback Screen
```
┌─────────────────────────────────┐
│ ← Feedback                      │
├─────────────────────────────────┤
│                                 │
│ How was the AI/ML Workshop?     │
│                                 │
│ Overall Rating                  │
│ ⭐⭐⭐⭐⭐                      │
│                                 │
│ Content Quality                 │
│ ⭐⭐⭐⭐⭐                      │
│                                 │
│ Instructor Rating               │
│ ⭐⭐⭐⭐⭐                      │
│                                 │
│ Venue Rating                    │
│ ⭐⭐⭐⭐⭐                      │
│                                 │
│ Comments (Optional)             │
│ ┌─────────────────────────────┐ │
│ │ Great workshop! Very        │ │
│ │ informative and well-       │ │
│ │ structured. The hands-on    │ │
│ │ examples were helpful.      │ │
│ │                             │ │
│ └─────────────────────────────┘ │
│                                 │
│ Would you recommend this event? │
│ ○ Yes    ○ No    ○ Maybe        │
│                                 │
│ ┌─────────────────────────────┐ │
│ │      [Submit Feedback]      │ │
│ └─────────────────────────────┘ │
│                                 │
└─────────────────────────────────┘
```

## Design System & Components

### Color Palette
- **Primary**: #2563EB (Blue)
- **Secondary**: #7C3AED (Purple)
- **Success**: #059669 (Green)
- **Warning**: #D97706 (Orange)
- **Error**: #DC2626 (Red)
- **Gray Scale**: #F9FAFB, #F3F4F6, #E5E7EB, #9CA3AF, #6B7280, #374151, #1F2937

### Typography
- **Headings**: Inter, Bold
- **Body**: Inter, Regular
- **Monospace**: JetBrains Mono

### Component Library
- **Buttons**: Rounded corners, consistent padding, hover states
- **Cards**: Subtle shadows, rounded corners, proper spacing
- **Forms**: Clear labels, validation states, helpful placeholders
- **Navigation**: Clear hierarchy, active states, responsive design
- **Icons**: Consistent style, appropriate sizing, semantic meaning

### Responsive Design
- **Mobile First**: Design starts with mobile constraints
- **Breakpoints**: 
  - Mobile: 320px - 768px
  - Tablet: 768px - 1024px
  - Desktop: 1024px+
- **Touch Targets**: Minimum 44px for mobile interactions
- **Accessibility**: WCAG 2.1 AA compliance, keyboard navigation, screen reader support
