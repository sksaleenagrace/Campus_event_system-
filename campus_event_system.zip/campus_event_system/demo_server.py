#!/usr/bin/env python3
"""
Simple demo server for Campus Event System
This creates a basic HTTP server to demonstrate the API endpoints without requiring PostgreSQL
"""

import json
import http.server
import socketserver
from urllib.parse import urlparse, parse_qs
from datetime import datetime
import uuid

# Sample data for demo
SAMPLE_COLLEGES = [
    {
        "id": "550e8400-e29b-41d4-a716-446655440001",
        "name": "Tech University",
        "code": "TU",
        "address": "123 Tech Street, Silicon Valley",
        "contact_email": "admin@techuni.edu"
    },
    {
        "id": "550e8400-e29b-41d4-a716-446655440002", 
        "name": "Engineering College",
        "code": "EC",
        "address": "456 Engineering Ave, Tech City",
        "contact_email": "info@engcollege.edu"
    }
]

SAMPLE_EVENTS = [
    {
        "id": "550e8400-e29b-41d4-a716-446655440030",
        "college_id": "550e8400-e29b-41d4-a716-446655440001",
        "title": "AI/ML Workshop",
        "description": "Hands-on workshop on machine learning basics",
        "event_type": "workshop",
        "start_time": "2024-03-15T10:00:00Z",
        "end_time": "2024-03-15T16:00:00Z",
        "venue": "Computer Lab 1",
        "max_capacity": 50,
        "is_active": True
    },
    {
        "id": "550e8400-e29b-41d4-a716-446655440031",
        "college_id": "550e8400-e29b-41d4-a716-446655440001", 
        "title": "Tech Fest 2024",
        "description": "Annual technology festival with competitions",
        "event_type": "fest",
        "start_time": "2024-03-20T09:00:00Z",
        "end_time": "2024-03-22T18:00:00Z",
        "venue": "Main Auditorium",
        "max_capacity": 500,
        "is_active": True
    }
]

SAMPLE_REPORTS = {
    "registrations_per_event": {
        "report_type": "registrations_per_event",
        "generated_at": datetime.now().isoformat() + "Z",
        "data": [
            {
                "event_id": "550e8400-e29b-41d4-a716-446655440031",
                "event_title": "Tech Fest 2024",
                "event_type": "fest",
                "college_name": "Tech University",
                "total_registrations": 387,
                "active_registrations": 368,
                "cancelled_registrations": 19,
                "capacity_utilization": 73.6
            },
            {
                "event_id": "550e8400-e29b-41d4-a716-446655440030",
                "event_title": "AI/ML Workshop",
                "event_type": "workshop", 
                "college_name": "Tech University",
                "total_registrations": 47,
                "active_registrations": 45,
                "cancelled_registrations": 2,
                "capacity_utilization": 90.0
            }
        ]
    },
    "attendance_percentage": {
        "report_type": "attendance_percentage",
        "generated_at": datetime.now().isoformat() + "Z",
        "data": [
            {
                "event_id": "550e8400-e29b-41d4-a716-446655440030",
                "event_title": "AI/ML Workshop",
                "total_registrations": 45,
                "total_attendance": 38,
                "attendance_percentage": 84.4
            },
            {
                "event_id": "550e8400-e29b-41d4-a716-446655440031",
                "event_title": "Tech Fest 2024",
                "total_registrations": 368,
                "total_attendance": 295,
                "attendance_percentage": 80.2
            }
        ]
    },
    "event_popularity": {
        "report_type": "event_popularity",
        "generated_at": datetime.now().isoformat() + "Z",
        "data": [
            {
                "rank": 1,
                "event_id": "550e8400-e29b-41d4-a716-446655440031",
                "event_title": "Tech Fest 2024",
                "event_type": "fest",
                "total_registrations": 368,
                "attendance_rate": 80.2,
                "average_rating": 4.1
            },
            {
                "rank": 2,
                "event_id": "550e8400-e29b-41d4-a716-446655440030",
                "event_title": "AI/ML Workshop", 
                "event_type": "workshop",
                "total_registrations": 45,
                "attendance_rate": 84.4,
                "average_rating": 4.2
            }
        ]
    }
}

class DemoHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # Set CORS headers
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
        
        response = {}
        
        # Route handling
        if path == '/':
            response = {
                "message": "Campus Event System API - Demo Mode",
                "version": "1.0.0",
                "docs": "/docs",
                "endpoints": {
                    "colleges": "/api/v1/colleges/",
                    "events": "/api/v1/events/",
                    "reports": "/api/v1/reports/",
                    "health": "/api/v1/health"
                }
            }
        elif path == '/api/v1/health':
            response = {
                "status": "healthy",
                "timestamp": datetime.now().isoformat() + "Z",
                "mode": "demo"
            }
        elif path == '/api/v1/colleges/':
            response = SAMPLE_COLLEGES
        elif path == '/api/v1/events/':
            response = SAMPLE_EVENTS
        elif path.startswith('/api/v1/reports/'):
            report_type = path.split('/')[-1]
            if report_type in SAMPLE_REPORTS:
                response = SAMPLE_REPORTS[report_type]
            else:
                response = {"error": "Report type not found", "available_reports": list(SAMPLE_REPORTS.keys())}
        elif path == '/docs':
            # Simple API documentation
            response = {
                "title": "Campus Event System API Documentation",
                "description": "Demo mode - showing sample data",
                "endpoints": [
                    {"path": "/", "method": "GET", "description": "API information"},
                    {"path": "/api/v1/health", "method": "GET", "description": "Health check"},
                    {"path": "/api/v1/colleges/", "method": "GET", "description": "List all colleges"},
                    {"path": "/api/v1/events/", "method": "GET", "description": "List all events"},
                    {"path": "/api/v1/reports/registrations_per_event", "method": "GET", "description": "Registration report"},
                    {"path": "/api/v1/reports/attendance_percentage", "method": "GET", "description": "Attendance report"},
                    {"path": "/api/v1/reports/event_popularity", "method": "GET", "description": "Popularity report"}
                ]
            }
        else:
            response = {"error": "Endpoint not found", "path": path}
        
        self.wfile.write(json.dumps(response, indent=2).encode())
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()

if __name__ == "__main__":
    PORT = 8000
    with socketserver.TCPServer(("", PORT), DemoHandler) as httpd:
        print(f"🚀 Campus Event System Demo Server")
        print(f"📡 Server running at: http://localhost:{PORT}")
        print(f"📖 API Documentation: http://localhost:{PORT}/docs")
        print(f"🏥 Health Check: http://localhost:{PORT}/api/v1/health")
        print(f"🏫 Colleges: http://localhost:{PORT}/api/v1/colleges/")
        print(f"📅 Events: http://localhost:{PORT}/api/v1/events/")
        print(f"📊 Reports: http://localhost:{PORT}/api/v1/reports/registrations_per_event")
        print(f"\n✨ Demo Mode: Showing sample data without database")
        print(f"🛑 Press Ctrl+C to stop the server")
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print(f"\n🛑 Server stopped")
            httpd.shutdown()
